Running the demo:
-----------------

The following dlls are neccesary and must be placed in this directory or in the 
\WINNT\system32 directory:

iconv.dll
libxml2.dll
libxslt.dll

You can download them at:

http://www.fh-frankfurt.de/~igor/projects/libxml/index.html

Type:

> transform

from the console and you get an explanation on the screen.


Learning the libxslt-api:
-------------------------

Have a look at:
http://xmlsoft.org/XSLT/

So far the code is tested with Delphi 6 only.

Best regards:

Uwe Fechner
