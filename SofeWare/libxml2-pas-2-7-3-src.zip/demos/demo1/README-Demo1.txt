Running the demo:
-----------------

The following dlls are neccesary and must be in PATH:

iconv.dll
libxml2.dll

You can download them at:

http://www.fh-frankfurt.de/~igor/projects/libxml/index.html

Type:

> demo1

from the console and you get an explanation on the screen.


Learning the libxml2-api:
-------------------------

Have a look at:
http://xmlsoft.org/html/libxml-lib.html

or at:

http://xmlsoft.org/docs.html

Best regards:

Uwe Fechner
