simplexslt (XSLT processor based on libxslt translated to delphi)
      see: http://sf.net/projects/libxml2-pas for more info
Written by Michael Pakhantsov.

Usage:
  simplexslt source stylesheet [options] [param=value...]

Options:
  -h, -H, -?          Displays this help text.
  -o filename         write output to named file.
  -m startMode        Start transform with this mode
