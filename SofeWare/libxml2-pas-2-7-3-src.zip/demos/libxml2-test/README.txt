TestParseFile is a simple app to test these functions: 
- xmlParseFile
- xmlFreeDoc

Use with one argument - name of an XML file:

TestParseFile test.xml

The program will read the document, release it, and say if it parsed well.

Petr Kozelka