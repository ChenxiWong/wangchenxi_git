# Last Update:2017-01-19 17:21:50
#########################################################################
# File Name: iptux_setup.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: Thu 19 Jan 2017 05:21:50 PM CST
# brief:
#########################################################################
#!/bin/bash
yum -y install *GConf2-dev*
