
/* Gettext Package. */
#undef GETTEXT_PACKAGE

/* System Execute Directory */
#undef __EXEC_PATH

/* System Data Directory */
#undef __DATA_PATH

/* System Locale Directory */
#undef __LOCALE_PATH

/* System Applications Directory */
#undef __DESKTOP_PATH

/* Iptux Logo Directory */
#undef __LOGO_PATH

/* Iptux Pixmaps Directory */
#undef __PIXMAPS_PATH

/* Iptux Sound Directory */
#undef __SOUND_PATH

/* Define if you want to use defined macros for iptux */
#undef __IP_TUX__

/* Define if you system has installed gstreamer already */
#undef HAVE_GST

/* Define if you want to print message */
#undef MESSAGE

/* Define if you want to print warning */
#undef WARNING

/* Define if you want to print trace */
#undef TRACE