# Last Update:2017-02-28 10:44:04
#########################################################################
# File Name: mysql_rsyslog_build.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: 2017年02月28日 星期二 10时44分04秒
#########################################################################
#!/bin/bash
systemctl stop mysqld.service
systemctl stop rsyslog.service
rpm -qa|grep mariadb|xargs -n 1 rpm -e  --nodeps
rpm -qa|grep mysql|xargs -n 1 rpm -e  --nodeps
rpm -qa | grep rsyslog | xargs -n 1 rpm -e --nodeps
rm -rf /var/lib/mysql*
rpm -ivh mysql-community-server-5.6.35-2.el7.x86_64.rpm mysql-community-client-5.6.35-2.el7.x86_64.rpm mysql-community-common-5.6.35-2.el7.x86_64.rpm mysql-community-devel-5.6.35-2.el7.x86_64.rpm mysql-community-libs-5.6.35-2.el7.x86_64.rpm mysql-community-release-el7-5.noarch.rpm 
rpm_install()
{
    TMP_STR=$(rpm -qa|grep $1)
    if [ -z $TMP_STR ]; then
        rpm -ivh $2
    fi
}
rpm_install 'libgt-0.3' 'libgt-0.3.11-1.el7.x86_64.rpm'
rpm_install 'libfastjson4-0' 'libfastjson4-0.99.4-1.el7.x86_64.rpm'
rpm -ivh rsyslog-8.25.0-1.el7.x86_64.rpm
rpm -ivh rsyslog-mmjsonparse-8.25.0-1.el7.x86_64.rpm
rpm -ivh rsyslog-mysql-8.25.0-1.el7.x86_64.rpm
systemctl start mysqld.service
systemctl enable mysqld.service
\cp  ./rsyslog.conf /etc/
systemctl start rsyslog.service
systemctl enable rsyslog.service
echo " "
echo " "
echo "请直接按回车键，不需要任何输入！！！"
echo " "
echo " "
mysql -uroot -p<./mysql-createDB.sql
echo " "
echo " "
echo " "
echo "sql脚本默认将用户root的密码设置为12345678"
echo " "
echo " "
echo " "
echo " "
