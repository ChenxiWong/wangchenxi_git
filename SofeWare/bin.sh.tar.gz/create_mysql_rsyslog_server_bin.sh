# Last Update:2017-02-28 13:49:37
#########################################################################
# File Name: create_mysql_rsyslog_server_bin.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: 2017年02月28日 星期二 13时49分37秒
#########################################################################
#!/bin/bash
if [ -a "./mysql_rsyslog.tar.gz" ]; then
    rm -rf ./mysql_rsyslog.tar.gz
fi
tar -zvcf mysql_rsyslog.tar.gz mysql-community-* rsyslog-* mysql-createDB.sql rsyslog.conf mysql_rsyslog_build.sh libfastjson4-0.99.4-1.el7.x86_64.rpm libgt-0.3.11-1.el7.x86_64.rpm
cat install_mysql_rsyslog_server.sh mysql_rsyslog.tar.gz > mysql_rsyslog_server.bin
chmod 775 mysql_rsyslog_server.bin
rm -rf ./mysql_rsyslog.tar.gz
