# Last Update:2017-02-28 13:46:29
#########################################################################
# File Name: install_mysql_rsyslog_server.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: 2017年02月28日 星期二 13时46分29秒
#########################################################################
#!/bin/bash
systemctl stop firewalld.service
systemctl disable firewalld.service
echo " "
echo " "
echo "完整搭建日志处理系统需要安装rsyslog、mysql、oracle客户端，三个服务"
sleep 5
echo " "
echo " "
dir_tmp=/opt/mysql_rsyslog_setup
if [ -d "$dir_tmp" ]; then
    rm -rf $dir_tmp
fi
mkdir -p $dir_tmp
sed -n -e '1,/^exit 0$/!p'  $0 > "${dir_tmp}/mysql_rsyslog.tar.gz"  2>/dev/null 
sleep 1
cd $dir_tmp
tar -zvxf  mysql_rsyslog.tar.gz
 echo "解压完成,现在开始安装。"
./mysql_rsyslog_build.sh 
echo " "
echo " "
echo "日志处理系统rsyslog、mysql环境初步搭建完毕。"
sleep 5
echo " "
echo " "
echo " "
ifconfig
echo " "
echo " "
echo " "
echo "请查询本台服务器的IP地址，方便其他还原处理器配置。"
echo " "
echo " "
echo " "
echo " "
echo " "
sleep 5
echo " "

exit 0
