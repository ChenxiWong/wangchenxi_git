echo "请输入日志处理模块所在服务器IP地址："
echo ""
read SERVER_IP
echo ""
systemctl stop firewalld.service
systemctl disable firewalld.service
ConfigFile=/etc/rsyslog.conf
echo "# rsyslog configuration file" >$ConfigFile
echo "" >>$ConfigFile
echo "# For more information see /usr/share/doc/rsyslog-*/rsyslog_conf.html" >>$ConfigFile
echo "# If you experience problems, see http://www.rsyslog.com/doc/troubleshoot.html" >>$ConfigFile
echo "" >>$ConfigFile
echo "#### MODULES ####" >>$ConfigFile
echo "#\$ModLoad ommysql" >>$ConfigFile
echo "" >>$ConfigFile
echo "# The imjournal module bellow is now used as a message source instead of imuxsock." >>$ConfigFile
echo "\$ModLoad imuxsock # provides support for local system logging (e.g. via logger command)" >>$ConfigFile
echo "\$ModLoad imjournal # provides access to the systemd journal" >>$ConfigFile
echo "\$ModLoad imklog # reads kernel messages (the same are read from journald)" >>$ConfigFile
echo "\$ModLoad immark  # provides --MARK-- message capability" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Provides UDP syslog reception" >>$ConfigFile
echo "\$ModLoad imudp" >>$ConfigFile
echo "\$UDPServerRun 514" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Provides TCP syslog reception" >>$ConfigFile
echo "#\$ModLoad imtcp" >>$ConfigFile
echo "#\$InputTCPServerRun 514" >>$ConfigFile
echo "" >>$ConfigFile
echo "" >>$ConfigFile
echo "#### GLOBAL DIRECTIVES ####" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Where to place auxiliary files" >>$ConfigFile
echo "\$WorkDirectory /var/lib/rsyslog" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Use default timestamp format" >>$ConfigFile
echo "\$ActionFileDefaultTemplate RSYSLOG_TraditionalFileFormat" >>$ConfigFile
echo "" >>$ConfigFile
echo "# File syncing capability is disabled by default. This feature is usually not required," >>$ConfigFile
echo "# not useful and an extreme performance hit" >>$ConfigFile
echo "#\$ActionFileEnableSync on" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Include all config files in /etc/rsyslog.d/" >>$ConfigFile
echo "\$IncludeConfig /etc/rsyslog.d/*.conf" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Turn off message reception via local log socket;" >>$ConfigFile
echo "# local messages are retrieved through imjournal now." >>$ConfigFile
echo "\$OmitLocalLogging on" >>$ConfigFile
echo "" >>$ConfigFile
echo "# File to store the position in the journal" >>$ConfigFile
echo "\$IMJournalStateFile imjournal.state" >>$ConfigFile
echo "" >>$ConfigFile
echo "" >>$ConfigFile
echo "#### RULES ####" >>$ConfigFile
echo "local7.info $SERVER_IP:514" >>$ConfigFile
echo "#local7.info :ommysql:127.0.0.1,Syslog,root,12345678" >>$ConfigFile
echo "# Log all kernel messages to the console." >>$ConfigFile
echo "# Logging much else clutters up the screen." >>$ConfigFile
echo "#kern.*                                                 /dev/console" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Log anything (except mail) of level info or higher." >>$ConfigFile
echo "# Don't log private authentication messages!" >>$ConfigFile
echo "*.info;mail.none;authpriv.none;cron.none                /var/log/messages" >>$ConfigFile
echo "" >>$ConfigFile
echo "# The authpriv file has restricted access." >>$ConfigFile
echo "authpriv.*                                              /var/log/secure" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Log all the mail messages in one place." >>$ConfigFile
echo "mail.*                                                  -/var/log/maillog" >>$ConfigFile
echo "" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Log cron stuff" >>$ConfigFile
echo "cron.*                                                  /var/log/cron" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Everybody gets emergency messages" >>$ConfigFile
echo "*.emerg                                                 :omusrmsg:*" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Save news errors of level crit and higher in a special file." >>$ConfigFile
echo "uucp,news.crit                                          /var/log/spooler" >>$ConfigFile
echo "" >>$ConfigFile
echo "# Save boot messages also to boot.log" >>$ConfigFile
echo "local7.*                                                /var/log/boot.log" >>$ConfigFile
echo "" >>$ConfigFile
echo "# ### begin forwarding rule ###" >>$ConfigFile
echo "# The statement between the begin ... end define a SINGLE forwarding" >>$ConfigFile
echo "# rule. They belong together, do NOT split them. If you create multiple" >>$ConfigFile
echo "# forwarding rules, duplicate the whole block!" >>$ConfigFile
echo "# Remote Logging (we use TCP for reliable delivery)" >>$ConfigFile
echo "#" >>$ConfigFile
echo "# An on-disk queue is created for this action. If the remote host is" >>$ConfigFile
echo "# down, messages are spooled to disk and sent when it is up again." >>$ConfigFile
echo "#\$ActionQueueFileName fwdRule1 # unique name prefix for spool files" >>$ConfigFile
echo "#\$ActionQueueMaxDiskSpace 1g   # 1gb space limit (use as much as possible)" >>$ConfigFile
echo "#\$ActionQueueSaveOnShutdown on # save messages to disk on shutdown" >>$ConfigFile
echo "#\$ActionQueueType LinkedList   # run asynchronously" >>$ConfigFile
echo "#\$ActionResumeRetryCount -1    # infinite retries if host is down" >>$ConfigFile
echo "# remote host is: name/ip:port, e.g. 192.168.0.1:514, port optional" >>$ConfigFile
echo "#*.* @@remote-host:514" >>$ConfigFile
echo "# ### end of the forwarding rule ###" >>$ConfigFile
systemctl restart rsyslog.service
systemctl enable rsyslog.service
