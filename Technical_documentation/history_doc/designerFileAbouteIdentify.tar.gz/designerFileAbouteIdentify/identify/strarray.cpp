#include"npr_identify.h"
#include "strarray.h"

#undef STRARRAYGROW
#define STRARRAYGROW  10

CStrArray::CStrArray()
{
	m_strTab  = NULL;
	m_curno   = 0;
	m_total   = 0;
}


CStrArray::~CStrArray()
{
	Close();
}

void CStrArray::Close()
{
	if(m_strTab)
	{
		for(int i=0;i<m_curno;i++)
		{
			if(m_strTab[i])
				delete m_strTab[i];
		}
		
		delete [] m_strTab;
		m_strTab = NULL;
	}
	m_curno   = 0;
	m_total   = 0;

}

int	CStrArray::Add(CStr *newstr)
{
	CStr **pTmp = NULL;
	if(m_curno>=m_total)
	{
		pTmp = new CStr*[m_total+STRARRAYGROW];
		memset(pTmp,0,sizeof(CStr*)*(m_total+STRARRAYGROW));
		memcpy(pTmp, m_strTab, m_curno * sizeof(CStr*));
		delete [] m_strTab;
		m_strTab = pTmp;
		m_total += STRARRAYGROW;
	}
	m_strTab[m_curno] = newstr;
	return m_curno++;
}


int  CStrArray::Add(const CStr &newstr)
{
	CStr *p = new CStr(newstr);
	return Add(p);
}

void CStrArray::SetAt( int nIndex,const  CStr& newstr )
{
	CStr *p = new CStr(newstr);
	SetAt(nIndex,p);
}

void CStrArray::InsertAt( int nIndex,const  CStr& newstr )
{
	CStr *p = new CStr(newstr);
	InsertAt(nIndex,p);
}


void CStrArray::SetAt( int nIndex, CStr* newstr )
{
	if(nIndex>=0&&nIndex<m_curno)
	{
		delete m_strTab[nIndex];
		m_strTab[nIndex] = newstr;
	}
	else
		assert(false);
}

void CStrArray::InsertAt( int nIndex, CStr* newstr )
{
	CStr **pTmp = NULL;
	if(nIndex>=0&&nIndex<=m_curno)
	{
		if(m_curno>=m_total)
		{
			pTmp = new CStr*[m_total+STRARRAYGROW];
			memset(pTmp,0,sizeof(CStr*)*(m_total+STRARRAYGROW));
			memcpy(pTmp, m_strTab, m_curno * sizeof(CStr*));
			delete m_strTab;
			m_strTab = pTmp;
			m_total += STRARRAYGROW;
		}

	    memmove(m_strTab+nIndex+1,m_strTab+nIndex,(m_curno-nIndex)*sizeof(CStr*));
	    m_strTab[nIndex] = newstr;
	    m_curno++;
	}
	else
		assert(false);
}

int CStrArray::Remove(CStr *remstr)
{
	for(int i=0;i<m_curno;i++)
		if(m_strTab[i]==remstr)
		{
			delete m_strTab[i];
			memmove(m_strTab+i,m_strTab+i+1,(m_curno-(i+1))*sizeof(CStr*));
			m_curno--;
			return 1;
		}
		return 0;
}


void CStrArray::RemoveAt( int nIndex)
{
	if(nIndex>=0&&nIndex<m_curno)
	{
		delete m_strTab[nIndex];
		memmove(m_strTab+nIndex,m_strTab+nIndex+1,(m_curno-(nIndex+1))*sizeof(CStr*));
		m_curno--;
	}
}

bool CStrArray::RemoveAll()
{
	for(int i=0;i<m_curno;i++)
	{
		delete m_strTab[i];
	}
	m_curno = 0;

	return true;	
}




