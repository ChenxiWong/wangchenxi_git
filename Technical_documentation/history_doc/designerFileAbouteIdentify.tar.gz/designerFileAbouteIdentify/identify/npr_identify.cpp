// Last Update:2016-09-14 09:44:09
/**
 * @file npr_identify.cpp
 * @brief 
 * @author wangchenxi
 * @version 0.1.00
 * @date 2016-09-14
 */
#include <stdio.h>
#include <iostream>
#include <fstream>
#include "protoclassify.h"
#include "strarray.h"
#include "mystr.h"
#include "ini.h"
#include "macrodef.h"

#define PrintForDebug(code)  HereIsDebug(code, __FILE__, __LINE__, __func__, __DATE__, __TIME__)

void HereIsDebug(const char* strerr, const char* file, int line, const char* func, const char* date, const char* time )
{
    printf("Error occured in file:%s line:%d , while calling function:%s .\n", file, line, func);
    printf("The final compilation of %s happend at %s in %s .\n", file, time, date);
    printf("Author-defined error TIP is \" %s \" .\n", strerr);
}

bool NprIdentify::LineToProtoStruct(string& line)
{
    ProtoStruct* pStruct = new ProtoStruct;
    if( -1 == sscanf(line.c_str(), "%s %u", pStruct->szName, (unsigned int*)&pStruct->nModuleID))
    {

        DBGCODE( line = " line : \"" + line + "\" " + " Load Failure!\n";
                line += " That cause NprIdentify::LineToProtoStruct(...), Failure! \n";
                PrintForDebug(line.c_str()); );

        return false;
    }
    m_protocol[pStruct->nModuleID] = pStruct;
    return true;
}

bool NprIdentify::AddIniFile(const char* iniPath)
{
    if(!((CIni*)m_ini)->Load(iniPath))
    {

        DBGCODE( PrintForDebug("NprIdentify::AddIniFile(...), Failure!"); );
        return false;

    }
    return true;
}

bool NprIdentify::LoadConfig(const char* confPath)
{
    ifstream in(confPath, ios::in);
    string line("");
    while(1)
    {
        getline(in, line);
        if(!in)break;
        if(!LineToProtoStruct(line))
        {

            DBGCODE( PrintForDebug("NprIdentify::LoadConfig(...), Failure!"); );
            line.clear();
            return false;

        }
        line.clear();
    }
    in.close();
    return true;
}

bool NprIdentify::LoadNprIdentify()
{
    UINT16 i = 0;
    for(;i < MAX_MODULE_NUM; ++i)
    {
        if(m_protocol[i] == 0)continue;
        CStrArray tmp_cstrArry;

        if(!((CIni*)m_ini)->HandleStringArray(true, m_protocol[i]->szName, "property", tmp_cstrArry))
        {
            DBGCODE( PrintForDebug("NprIdentify::m_ini.HandleStringArray(...), Failure!"); );
            return false;
        }

        if(!((CProtoClassify*)m_classify)->LoadProto(tmp_cstrArry, m_protocol[i]))
        {

            DBGCODE( PrintForDebug("NprIdentify::m_classify.LoadProto(...), Failure!"); );
            return false;

        }
    }
    return true;
}



NprIdentify::NprIdentify(const char* iniPath, const char* confPath)
{
    m_ini = new CIni();
    m_classify = new CProtoClassify();

    memset(m_protocol, 0, MAX_MODULE_NUM*sizeof(void*));

    if(!AddIniFile(iniPath))
    {
        PrintForDebug("NprIdentify::NprIdentify(...), Failure!");exit( EXIT_FAILURE);
    }
    if(!LoadConfig(confPath))
    {
        PrintForDebug("NprIdentify::NprIdentify(...), Failure!");exit( EXIT_FAILURE);
    }
    if(!LoadNprIdentify())
    {
        PrintForDebug("NprIdentify::NprIdentify(...), Failure!");exit( EXIT_FAILURE);
    }
}

NprIdentify::~NprIdentify()
{
    UINT16 i = 0;
    for(;i < MAX_MODULE_NUM; ++i)
    {
        if(m_protocol[i] == 0)continue;
        delete m_protocol[i];
        m_protocol[i] = 0;
    }

    delete (CIni*)m_ini;
    m_ini = NULL;

    delete (CProtoClassify*)m_classify;
    m_classify = NULL;
}

ProtoStruct* NprIdentify::GetProtoStruct(UINT16 index)
{
    return m_protocol[index];
}

//查找协议特征码
bool NprIdentify::FindProto(UINT32 nProType, IPv4ConnectAddr& connectAddr, char *Buffer, int nstrLen, ProtoId & ProtoIDVar)
{
    return ((CProtoClassify*)m_classify)->FindProto( nProType, connectAddr, Buffer, nstrLen, ProtoIDVar);
}

// 通过端口进行协议判断，返回协议id结构、连接方向，用于socket代理
bool NprIdentify::FindProto(UINT32 nProType, UINT16 nPort, char *pBuffer, int nstrLen, ProtoId& ProtoIDVar)
{
    return ((CProtoClassify*)m_classify)->FindProto( nProType, nPort, pBuffer, nstrLen, ProtoIDVar);
}

//释放资源，初始化
void NprIdentify::Close()
{
    ((CProtoClassify*)m_classify)->Close();
}

//根据协议id设置协议有效，1表示加载成功。-1表示加载未成功或者出现异常
INT16 NprIdentify::SetProto(ProtoId & ProtoIdVar)
{
    return ((CProtoClassify*)m_classify)->SetProto(ProtoIdVar);
}

//根据协议id设置协议无效，1表示卸载成功。-1表示卸载未成功或者出现异常
INT16 NprIdentify::UnsetProto(ProtoId & ProtoIdVar)
{
    return ((CProtoClassify*)m_classify)->UnsetProto(ProtoIdVar);
}

//根据协议级别设置协议有效，-1表示未加载任何协议或者出现异常，〉0的整数表示加载的协议个数
INT16 NprIdentify::SetProtoByLevel(UINT32	& nLevel)
{
    return((CProtoClassify*)m_classify)->SetProtoByLevel(nLevel);
}

//根据协议级别设置协议无效，-1表示未卸载任何协议或者出现异常，〉0的整数表示卸载的协议个数
INT16 NprIdentify::UnsetProtoByLevel(UINT32	& nLevel)
{
    return ((CProtoClassify*)m_classify)->UnsetProtoByLevel(nLevel);
}

/*支持IPv6 解析新增*/
//IPv6 查找协议特征码
bool NprIdentify::FindProtoIPv6(UINT32 nProType, IPv6ConnectAddr& connectAddr, char *pBuffer, int nstrLen, ProtoId & ProtoIDVar)
{
    return ((CProtoClassify*)m_classify)->FindProtoIPv6(nProType, connectAddr, pBuffer, nstrLen, ProtoIDVar);
}

