/*=========================================================
*	File name	��	allocfix.cpp
*	Authored by	��	DAIHW
*	Date		��	2008-1-21 21:05:18
*	Description	��	implementation of fixed block allocator
*
*	Modify  	��	
*=========================================================*/
#include "npr_identify.h"
#include "allocfix.h"
#include <assert.h>
/////////////////////////////////////////////////////////////////////////////
// CCluster

#define ALLOCFIX_MAX_PTR_VALUE 0xffffffffffffffff

CCluster* CCluster::Create(CCluster*& pHead, UINT32 nMax, UINT32 cbElement)
{
	assert(nMax > 0 && cbElement > 0);
	CCluster* p = (CCluster*) new UCHAR[sizeof(CCluster) + nMax * cbElement];
	if (NULL == p)
		return NULL;
	p->pNext = pHead;
	pHead = p;  // change head (adds in reverse order for simplicity)
	return p;
}

void CCluster::FreeDataChain()     // free this one and links
{
	CCluster* p = this;
	while (p != NULL)
	{
		UCHAR* bytes = (UCHAR*) p;
		CCluster* pNextTmp = p->pNext;
		delete[] bytes;
		p = pNextTmp;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAllocFixed

CAllocFixed::CAllocFixed(UINT32 nAllocSize, UINT32 nAllocNum)
{
	assert(nAllocSize >= sizeof(CNode));
	assert(nAllocNum > 1);

	m_nAllocSize = nAllocSize;
	m_nBlockSize = nAllocNum;
	m_pNodeFree = NULL;
	m_pBlocks = NULL;
}

CAllocFixed::~CAllocFixed()
{
	FreeAll();
}

void CAllocFixed::FreeAll()
{
	m_Protect.Lock();
	m_pBlocks->FreeDataChain();
	m_pBlocks = NULL;
	m_pNodeFree = NULL;
	m_Protect.Unlock();
}

void* CAllocFixed::Alloc()
{
	CheckNodeNext();
	m_Protect.Lock();

	if (m_pNodeFree == NULL)
	{
		// add another block
		CCluster* pNewBlock = CCluster::Create(m_pBlocks, m_nBlockSize, m_nAllocSize);
		if (NULL == pNewBlock)
		{
			m_Protect.Unlock();
			return NULL;
		}
		// chain them into free list
		CNode* pNode = (CNode*)pNewBlock->data();
		// free in reverse order to make it easier to debug
		(UCHAR*&)pNode += (m_nAllocSize * m_nBlockSize) - m_nAllocSize;
		for (int i = m_nBlockSize-1; i >= 0; i--, (UCHAR*&)pNode -= m_nAllocSize)
		{
			pNode->pNext = m_pNodeFree;
			m_pNodeFree = pNode;
			assert(m_pNodeFree < (void *)ALLOCFIX_MAX_PTR_VALUE);
			if (m_pNodeFree)
				assert(m_pNodeFree->pNext < (void *)ALLOCFIX_MAX_PTR_VALUE);
		}
	}
	assert(m_pNodeFree != NULL);  // we must have something

	
	
	// remove the first available node from the free list
	void* pNode = m_pNodeFree;
	m_pNodeFree = m_pNodeFree->pNext;
	m_Protect.Unlock();
	CheckNodeNext();
	return pNode;
}

void CAllocFixed::Free(void* p)
{
	if (p != NULL)
	{
		CheckNodeNext();
		m_Protect.Lock();
		
		// simply return the node to the free list
		CNode* pNode = (CNode*)p;
		pNode->pNext = m_pNodeFree;
		m_pNodeFree = pNode;
		

		m_Protect.Unlock();
		CheckNodeNext();
	}
}

void CAllocFixed::CheckNodeNext()
{
/*
	m_Protect.Lock();
	CNode * p = m_pNodeFree;
	while(p)
	{
		assert(p < (void *)ALLOCFIX_MAX_PTR_VALUE);
		p = p->pNext;		
	}
	m_Protect.Unlock();
*/
}

