/*=========================================================
 * File name �� structdef.h
 * Authored by �� daihw
 * Date  �� 2005-3-4 15:00:47
 * Description �� 
 *
 * Modify by  �� yinying
 *       Date            :       2008-4-2 16:35
 *=========================================================*/
#ifndef __DECODEDEF_H__
#define __DECODEDEF_H__
#include "macrodef.h"  //�궨���ļ�
//#include "service/servicemanager.h"
//#include "service/ipfilter.h"

#endif // __DECODEDEF_H__
