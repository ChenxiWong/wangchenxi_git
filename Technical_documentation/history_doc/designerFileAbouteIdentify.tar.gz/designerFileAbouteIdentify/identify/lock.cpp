/*=========================================================
*	File name	��	seclock.cpp
*	Authored by	��	xuxinyao
*	Date		��	2001-9-4 11:37:26
*	Description	��	
*
*	Modify  	��	 
*=========================================================*/

#include "npr_identify.h"
#include "lock.h"

CLock::CLock()
{
#ifdef WINDOWS_TRANSFORMER
	::InitializeCriticalSection(&m_Sect);
#endif
	
#ifdef LINUX_TRANSFORMER
	static int sum =0;
	int res = pthread_mutex_init(&m_Mutex,NULL);
	if (0!=res)
	{
		printf("common mutex init error!\n");
	}
	else
	{
		(void)sum;
		//printf("common mutex init return=%d sum=%d\n",res,++sum);
	}
	

	
#endif
}

CLock::~CLock()
{
#ifdef WINDOWS_TRANSFORMER
	::DeleteCriticalSection(&m_Sect);
#endif
	
#ifdef LINUX_TRANSFORMER
	pthread_mutex_destroy(&m_Mutex);
#endif
}


