/*=============================================================================
*	File name	��	lock.h
*	Authored by	��	daihw
*	Date		��	2006-6-8 8:51:36
*	Description	��	
*
*	Modify  	��	
*=============================================================================*/
#ifndef __LOCK_H__
#define __LOCK_H__

//#ifdef WIN32
//#include <afxwin.h>
//#endif

#include <pthread.h>

#define LINUX_TRANSFORMER


class CLock  
{
public:
	CLock();
	virtual ~CLock();
public:
	void Unlock();
	void Lock();
private:
	
#ifdef	WINDOWS_TRANSFORMER
	CRITICAL_SECTION m_Sect;
#endif
	
#ifdef	LINUX_TRANSFORMER
	pthread_mutex_t m_Mutex;
#endif
	
};

inline void CLock::Lock()
{
#ifdef WINDOWS_TRANSFORMER
	::EnterCriticalSection(&m_Sect);
#endif
	
#ifdef LINUX_TRANSFORMER
	pthread_mutex_lock(&m_Mutex);
#endif
}

inline void CLock::Unlock()
{
#ifdef WINDOWS_TRANSFORMER
	::LeaveCriticalSection(&m_Sect); 
#endif
	
#ifdef LINUX_TRANSFORMER
	pthread_mutex_unlock(&m_Mutex);
#endif
}

#endif // __LOCK_H__

