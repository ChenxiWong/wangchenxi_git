// Last Update:2016-09-10 09:00:20
/**
 * @file npr_identify.h
 * @brief 
 * @author wangchenxi
 * @version 0.1.00
 * @date 2016-09-10
 */

#ifndef NPR_IDENTIFY_H
#define NPR_IDENTIFY_H

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <vector>
//调试宏定义
#ifdef DEBUG
#define DBGCODE(code);  code
#else
#define DBGCODE(code);
#endif

#undef MAX_MODULE_NAME
#define MAX_MODULE_NAME 31 //协议名称字符串的长度范围

#undef MAX_MODULE_NUM
#define MAX_MODULE_NUM  256

using namespace std;

typedef unsigned char UCHAR;
typedef short int INT16;
typedef unsigned short UINT16; 
typedef int INT32;
typedef unsigned int UINT32;
typedef long long INT64;
typedef unsigned long long UINT64;
typedef pthread_t  HANDLE; 
typedef void *  POINTER;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

struct ProtoId
{
    //协议ID,其具体的数值由应用解码的管理模块生成
    UINT32  PID;
    //附属协议ID如传奇游戏中的聊天，登陆，游戏附属协议，具体的值由各个协议作定义
    UINT32  SID;
    //是否建链，主要是针对udp数据可以单包处理不需要建链 ,0 表示不建链，1表示建链
    UINT16  nCreateConn;
    //用于区分识别类型 0 表示端口识别， 1表示特征码识别。
    UINT32 TID;
};


struct ProtoStruct
{
    //协议（模块）名i
    char szName[MAX_MODULE_NAME+1];
    //部标格式的大协议ID
    char szBubiaoID[4];
    //部标格式的小协议ID
    char szBubiaopID[8];
    //协议的类别，例如：网络游戏类编号为 02
    UINT16 nProtoType;
    //协议ID,webbbs、webmail都有独立的协议ID但是都属于http模块，所以会有相同的模块ID
    UINT16 nProtoID;
    //模块ID
    UINT16 nModuleID;
    //模块优先级
    UINT16 nLevel;
    //标识当前协议是否是独立的模块，例如：smtp是独立的模块 webbbs就不是独立的模块
    bool bIsModule;
    //模块授权信息
    char szCopyRight[32];
    //WATYPE 如 WA_SOURCE_XXXX
    char szWaType[32];
    char szJzType[32];
    char szWapID[8];
    char szJzpID[8];
};

typedef const char* LPCTSTR;
typedef const char* LPCSTR;

struct TimeStamp
{
    int    tv_sec;         // seconds 
    int    tv_usec;        // and microseconds 
};

#define FLAG_FILTER_FILTED      0
#define FLAG_FILTER_CAPTURED    1
#define FLAG_FILTER_UNKNOWN     2

//#define INDEX_PID_IP_TCP        0
//#define INDEX_PID_IP_UDP        1
/*
1:IPv6 数据类型*/
#define IPv6_TYPE_OTHER     0
#define IPv6_TYPE_FULL        1
#define IPv6_TYPE_6OVER4_DIRECT  2
#define IPv6_TYPE_6OVER4_GRE        3
#define IPv6_TYPE_6PE          4
#define IPv6_TYPE_4OVER6_DIRECT  5
//隧道IP类型
#define TUNNEL_ADDR_NO      0
#define TUNNEL_ADDR_IP      1
#define TUNNEL_ADDR_IPv6        2
//IP层Version类型
#define IP_VERSION_IPv4     0x04
#define IP_VERSION_IPv6     0x06

struct AcInfo
{
    UINT64 pkt_count;
    UINT64 pkt_length;
    UINT64 ac_count;
    UINT64 ac_usval;
    UINT64 lt_count;
    UINT64 lt_usval;
    UINT32 max_prc;
};

struct IPv4TransportAddr 
{
    UINT32  nIP;
    UINT16   nPort;
};

struct IPv4ConnectAddr
{
    IPv4TransportAddr Client;
    IPv4TransportAddr Server;
    UINT32 nProtocol;
};


/*double IP layer ,dongxia add*/
struct DoubleIPv4ConnectAddr
{
    IPv4ConnectAddr ConnAddr;
    IPv4ConnectAddr SubConnAddr;
};

struct PackInfo
{
    char*   pPacketBuf;   //tcp数据 
    INT32   nPacketLen;   //tcp数据长度，可以被运行时改变大小 
    INT32   nPacketLenOrigin; //tcp数据长度，原始大小，不可改变，发送rst包时使用 
    char*   pMacHeader;   //MAC数据 
    INT32   nTotalPacketLen ; //数据总长度，包括所有的包头的长度 
    char*   pIPHeader;   //Ip数据 
    INT32   nIPHeaderLen;   //IP 包头长 
};


//判断突防类协议使用的信息结构，在进行DNS协议解析时，如果发现突防工具对应的域名，
//则把记录下突防服务器IP地址，通过该结构添加到DNSPool中。
struct AntiBlockageInfo
{
    //突防服务器IP地址和可能端口（0为端口任意）
    IPv4TransportAddr ServerAddr;
    //标示应用层协议ID
    UINT32 nProtocolID;
    //标示应用层协议子ID
    UINT32  nSubID;
    //当前节点的时戳
    UINT32 nTimeStamp;
    //突防服务器的域名
    char szName[128];
};

typedef bool (*PFADDDNSCONNECT)(AntiBlockageInfo* pDNSData, bool bImport);



struct ModuleInfo
{

    char  szName[MAX_MODULE_NAME + 1];  //模块名 
    UINT32  nID;       //模块ID 
    UINT32  nLevel;       //模块优先级 
    char  strCopyRight[32];    //模块授权信息
    bool  bFlag;        //是否该协议需要建立连接 
};


//创建应用层解码对象时传入的接口参数结构
struct Paras
{
    UINT32  nSID;    //协议的子ID，用来细分一个模块中的子协议，此值在协议特征码配置文件中定义
    char  chParaBuffer[1024]; // 预留的参数信息缓冲区，暂时没有用到
};




struct VpnPppProtocol
{
    IPv4ConnectAddr ConnAddrIntra;    //vpn ppp  协议中内部的ip地址
    UINT32          PortocolType;     //vpn ppp 协议中使用的协议类型，如l2tp 等
    UINT32          ProtocolControlType;   //ppp vpn 协议内部使用的类型，如这个包是链路控制包，网络控制包
    UINT32          PppVpnProtocolType;   // ppp vpn协议中封装的协议类型，如ip ipx等
    UINT32          VpnPppUseSeurtyProType;   // vpn ppp协议中使用的安全协议类型
    const UCHAR *  pIPheader;       //如果是vpn数据，这个指针保存的是最初进来的ip包头指针
    UINT32          nIPheaderlen;      //如果是vpn 数据，这里记录最初进入底层的ip包头长度
    UINT32          nIPPacketLen;      //如果是vpn数据 保存最初进入解码的ip长度
}; 

/*IPv6 相关的数据结构*/
//IPv6 传输地址
struct IPv6TransportAddr 
{
    UINT16 aIPv6[8];
    UINT16 nPort;
};
//IPv6 会话地址
struct IPv6ConnectAddr
{
    IPv6TransportAddr Client;
    IPv6TransportAddr Server;
    UINT32 nFlowLable;
    UINT32 nProtocol;
};
//IPv4 隧道地址
struct IPv4TunnelAddr
{
    UINT32 nSrcIP;
    UINT32 nDstIP; 
};
//IPv6 隧道地址
struct IPv6TunnelAddr
{
    UINT16 aSrcIPv6[8];
    UINT16 aDstIPv6[8];       
};
//IPv6隧道数据结构
struct IPv6TunnelData
{
    //隧道端口IP类型1IPv4 2 IPv6
    UINT32 nIPType;  
    IPv6TunnelAddr addr_ipv6;
    IPv4TunnelAddr addr_ipv4;        
};

struct TCPIPFilterContext
{
    UINT32    nError;             //错误包的类型，是mac|ip|tcp|udp|icmp|其他错误
    UINT32    nNetProtocl;  //网络层的协议类型，如ip协议，或者其他
    UINT32    nFilterFlag;  //与以前兼容，暂时不用
    UINT32    nIndexProtocl;  //传输层的协议类型，如tcp数据，或者是udp数据
    const UCHAR*  pTCPHeader;   //tcp、udp头指针，
    const UCHAR*  pIPHeader;   // ip头指针
    const UCHAR*  pMACHeader;   // mac头指针
    UINT32          nTotalPacketLen; //total packet len，包总长度 
    UINT32          nIPHeaderLen;  // ip头长度
    UINT32          nTCPPacketLen;  // tcp|udp包长度
    UINT32          nTCPHeaderLen;  // tcp|udp包头长度
    IPv4ConnectAddr ConnAddr;
    UINT16          VpnPppFlag;   //是否是vpn ppp数据 标志
    VpnPppProtocol  VpnPppContent ;  //如果是vpn ppp 数据，这个结构可以包括这种数据的一些信息
    IPv4ConnectAddr ConnAddrcdma;           //cdma数据中pcf和pdsn的ip对
    UINT32          Grekeycdma;   //cdma数据中gre层的grekey值
    UINT16          nVLanId;                //VLan ID
    UINT16          nSessionId ;           //Adsl Session ID 
    UCHAR*          pNewPPPHeader;  //用来解码的PPP缓存头指针
    UINT32          nAppProto;          //应用层协议类型字段  yyp add
    UCHAR*   pNewIPHeader;
    UINT32  nIPPayloadLen;
    bool  bReleaseiph;  //是否释放重组后的ipheader
    /*IPv6 新增数据结构*/
    //IPv6头指针
    UCHAR*          pIPv6Header;
    //IPv6 Head 长固定首部加扩展首部
    UINT32           nIPv6HeaderLen; 
    //IPv6 会话地址用户数据地址
    IPv6ConnectAddr ConnAddrIPv6;  
    //IPv6 隧道地址
    IPv6TunnelData  TunnelAddrIPv6;
    //IPv6 数据类型
    UINT32          nIPv6DataType;
    //IPv6 负载数据长
    UINT32  nIPv6PayloadLen;
    TCPIPFilterContext()
    {
        nError = 0;
        nNetProtocl = 0;
        nFilterFlag = 0;
        nIndexProtocl = 0;
        pTCPHeader = NULL;
        pIPHeader = NULL;
        pMACHeader = NULL;
        nTotalPacketLen = 0;
        nIPHeaderLen = 0;
        nTCPPacketLen = 0;
        nTCPHeaderLen = 0;
        nVLanId = 0 ;
        nSessionId = 0 ;
        nAppProto = 255; //将应用层的协议id初始化为other协议
        VpnPppFlag = 0;
        memset(&VpnPppContent, 0, sizeof(VpnPppContent));
        Grekeycdma = 0;
        pNewPPPHeader = NULL;
        memset(&ConnAddr, 0, sizeof(ConnAddr));
        memset(&ConnAddrcdma, 0, sizeof(ConnAddrcdma));
        nIPPayloadLen = 0;
        bReleaseiph = false;
        //IPv6数据初始化
        pIPv6Header = NULL;
        nIPv6HeaderLen = 0;
        nIPv6DataType = 0;
        nIPv6PayloadLen = 0;
        memset(&ConnAddrIPv6, 0,sizeof(IPv6ConnectAddr));
        memset(&TunnelAddrIPv6, 0,sizeof(IPv6TunnelData));
    }
};

//--- xiaodong - add sctp decode 2015-1-28---

/*sctp chunk header definition*/
typedef struct sctp_chunk_header_s{
    uint8_t type; 
    uint8_t flag;     /* resv:bit8-12, U(Unorder):消息无序，*/
    /* B(Begin):应用层消息起始部分,E(End):应用层消息结束部分 */
    uint16_t length;  /* 包含type/flag/length/value，如果不是4的倍数，
                         需要在chunk后加上padding，最多添加3个字节，
                         注意 : length不包含padding计数*/ 
}sctp_chunk_header_t;

/*sctp chunk data header definition(chunk type is 0)*/
typedef struct sctp_chunk_data_header_s{
    sctp_chunk_header_t chunk_header; 
    uint32_t tsn;      /*  */
    uint16_t sid;        /* stream identifier */
    uint16_t ssn;       /* stream sequence number */
    uint32_t protocol;      /* payload protocol identifier */
}sctp_chunk_data_header_t;

typedef struct tcp_header_s{
    uint16_t src_port;
    uint16_t dst_port;
    uint32_t seq_num;
    uint32_t ack_num;
    uint8_t  head_len;
    uint8_t  flags;
    uint16_t wsv;
    uint16_t checksum;
    uint16_t pading;
}tcp_header_t;

typedef struct udp_header_s{
    uint16_t src_port;
    uint16_t dst_port;
    uint16_t len;
    uint16_t checksum;
}udp_header_t;

//--- xiaodong - add sctp decode end---


class NprIdentify
{
    private:
        void* m_ini;
        ProtoStruct* m_protocol[MAX_MODULE_NUM];
        void* m_classify;

        bool LineToProtoStruct(string& line);

        bool AddIniFile(const char* iniPath);

        bool LoadConfig(const char* confPath);

        bool LoadNprIdentify();

    public:

        NprIdentify(const char* iniPath, const char* confPath);

        ~NprIdentify();

        ProtoStruct* GetProtoStruct(UINT16 index);

        //CProtoClassify* IdentifyProtocol();
        //查找协议特征码
        bool  FindProto(UINT32 nProType, IPv4ConnectAddr& connectAddr, char *Buffer, int nstrLen, ProtoId & ProtoIDVar);
        // 通过端口进行协议判断，返回协议id结构、连接方向，用于socket代理
        bool  FindProto(UINT32 nProType, UINT16 nPort, char *pBuffer, int nstrLen, ProtoId& ProtoIDVar);
        //释放资源，初始化
        void Close();

        //根据协议id设置协议有效，1表示加载成功。-1表示加载未成功或者出现异常
        INT16 SetProto(ProtoId & ProtoIdVar);
        //根据协议id设置协议无效，1表示卸载成功。-1表示卸载未成功或者出现异常
        INT16 UnsetProto(ProtoId & ProtoIdVar);
        //根据协议级别设置协议有效，-1表示未加载任何协议或者出现异常，〉0的整数表示加载的协议个数
        INT16 SetProtoByLevel(UINT32 & nLevel);
        //根据协议级别设置协议无效，-1表示未卸载任何协议或者出现异常，〉0的整数表示卸载的协议个数
        INT16 UnsetProtoByLevel(UINT32 & nLevel);
        /*支持IPv6 解析新增*/
        //IPv6 查找协议特征码
        bool  FindProtoIPv6(UINT32 nProType, IPv6ConnectAddr& connectAddr, char *pBuffer, int nstrLen, ProtoId & ProtoIDVar);
};

#endif  /*NPR_IDENTIFY_H*/
