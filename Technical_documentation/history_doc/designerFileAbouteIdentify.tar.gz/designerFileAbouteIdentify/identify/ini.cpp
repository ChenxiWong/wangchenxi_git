

#include <stdlib.h>
#include <fstream>

#ifdef WINDOWS_TRANSFORMER

#endif

#ifdef LINUX_TRANSFORMER
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#include "npr_identify.h"
#include "ini.h"
//#include "common/log.h"
/////////just for test cvs client BJRUN
CIni::CIni()
{
	csLineEnd = "\n";
	findposition=-1;
}

CIni::~CIni()
{
	Close();
}

bool CIni::CheckUpdate()
{ 
	//��鵱ǰ�ļ���״̬����������޸ĵ�ʱ����ļ��Ĵ�С�ж��ļ��Ƿ��޸�
	struct stat filestat;
	if (stat(m_szFileName, &filestat) == 0)
	{
		if (m_LastFileStat.st_size != filestat.st_size ||
			m_LastFileStat.st_mtime != filestat.st_mtime)
		{
			m_LastFileStat = filestat;
			return true;
		}
	}
	
	//�����ļ��ĸ���ʱ�䡢�ļ���С��У��͵������ж��ļ��Ƿ񱻸���
	return false;
}

bool CIni::Load(const char * cFileName)
{
	Close();
	//CStr *cs = NULL;
	
//	ifstream ifs(cFileName,std::ios::in);
	std::ifstream ifs(cFileName, std::ios::in);
	//daihw add 20061107
	if (!ifs.good())
	{
		return false;
	}

	char buf[1024];
	while (ifs.good())
	{
		ifs.getline(buf, sizeof(buf)-1);
		//cs = new CStr(buf);
		CStr cs(buf);
		cs.Replace(0x09,' ');//replace tab
		cs.Replace('\r', ' ');
		cs.Replace('\n',' ');
		cs.RTrim();
		cs.LTrim();
		if(!cs.IsEmpty())
		{
			csList.Add(cs);
		}
	}
	strcpy(m_szFileName, cFileName);
	return true;
}

bool CIni::Save(const char * cFileName, bool bIsWin )
{
	//ASSERT(cFileName);
	if(!cFileName)
		exit(1);
	std::ofstream	    handle;
//    handle.open(cFileName, std::ios::out);
	handle.open(cFileName, std::ios::out);
    if(!handle.good()) {
        //TRACE("%s %d WriteTxt %s Error\n", __FILE__, __LINE__, cFileName);
        return false;
	}
	int t, max = csList.GetSize();
	for (t = 0; t <max; t++)
	{
		CStr *s=csList.GetAt(t);
		if(IsSection(t))
		{
			if (bIsWin)
				handle<< "\r";
			handle<<"\n";
		}
		handle.write(s->GetString(),s->GetLength());
		if (bIsWin)
			handle<< "\r";
		handle<<"\n";
	}
	handle.close();
	return true;
}

// **********************************************************************************

void CIni::Close()
{
	csList.Close();
	findposition=-1;
}

// **********************************************************************************

int CIni::FindSection(const char * cSection)
{
	int t, max = csList.GetSize();
	CStr csSection;
	csSection.Format("[%s]", cSection);
	
	for (t = 0; t < max; t++)
	{
		CStr *iSection=csList.GetAt(t);
		//ASSERT(iSection);
		if(!iSection)
			exit(1);
		iSection->AllTrim();
		if (*iSection == csSection)
			return t;
	}
	
	return -1;
}

int CIni::FindSection2()
{
	int t, max = csList.GetSize();
	for (t = findposition+1; t < max; t++)
	{
		
		CStr *iSection = csList.GetAt(t);
		if(iSection[0]==';'/*||iSection[0]=='��'*/)
			continue;
		if (iSection->Find('[') != -1) 
		{
			findposition=t;
			if(IsSection(t))
				return t;
			return -1;
		}
	}
	findposition=-1;
	return -1;
	
}

int CIni::InsertSection(const char * cSection)
{
	//ASSERT(cSection);
	if(!cSection)
		return -1;
	if (!cSection) return -1;
	
	int idx = FindSection(cSection);
	if (idx < 0)
	{
		CStr *csSection = new CStr;
		csSection->Format("[%s]", cSection);
		idx = csList.Add(csSection);
	}
	return idx;
}

int CIni::FindItem(const int iSection, const char * cItem, CStr &csVal)
{
	//ASSERT(iSection >= 0);
	if(iSection<0)
		exit(1);
	//ASSERT(cItem);
	if(!cItem)
		exit(1);
	int max = csList.GetSize(), t;
	CStr csItem(cItem),csLook,csTmp;
	csItem += " = ";
	int iLen = csItem.GetLength();
	
	for (t = iSection; t < max; t++)
	{
		if(IsSection(t))
			return -1;

		csLook = *(csList.GetAt(t));
		if(csLook.GetAt(0)==';')
			continue;

		if (csLook.GetLength() >= iLen)
		{
			csLook.GetLeft(iLen,csTmp);
			
			if ( csTmp== csItem) 
			{   
				if (csLook.GetLength() == iLen) csVal = "";
				else 
				{
					csLook.GetRight(csLook.GetLength() - iLen,csVal);
					csVal.AllTrim();
				}
				return t;
			}
		}
	}
	return -1;
}



bool CIni::IsSection(const int iSection)
{
	//ASSERT(iSection >= 0 && iSection < csList.GetSize());
	if(!(iSection >= 0 && iSection < csList.GetSize()))
		exit(1);
	if (iSection >= 0 && iSection < csList.GetSize())
	{
		CStr leftItem,rightItem;
		CStr csItem = *(csList.GetAt(iSection));
		csItem.AllTrim();
		csItem.GetLeft(1,leftItem);
		csItem.GetRight(1,rightItem);
		if (csItem.GetLength() > 2 && csItem.GetAt(0) == '[' && csItem.GetAt(csItem.GetLength()-1) == ']' )//leftItem == "[" && rightItem == "]")
			return true;
	}
	return false;
}

bool CIni::RemoveItem2(const char * cSection, const char * cItem, CStr &csVal)
{
	int idx = FindSection(cSection);
	
	if (idx >= 0)
	{
		for (;;)
		{
			CStr cs;
			int id=FindItem(++idx,cItem,cs);
			if(id>=0)
			{
				if(cs==csVal)
				{
					csList.RemoveAt(id);
					return true;
				}
			}
			else
				return false;
		}
	}
	return false;
}

bool CIni::RemoveSection(const char * cSection)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		for (;;)
		{
			csList.RemoveAt(idx);
			if (idx >= csList.GetSize()) return true;
			if (IsSection(idx)) return true;
		}
	}
	return true;
}

void CIni::RemoveMultiItem(const char * cSection, const char * cItem)
{
	int idx = FindSection(cSection);
	
	if (idx >= 0)
	{
		for (;;)
		{
			CStr cs;
			int id=FindItem(idx+1,cItem,cs);
			if(id>=0)
			{
					csList.RemoveAt(id);
			}
			else
				return ;
		}
	}
	return ;
}
//xieb
bool CIni::RemoveAll()
{
	return csList.RemoveAll() ;
}

// **********************************************************************************

bool CIni::SetValue(const char * cSection, const char * cItem, const bool bVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %s", cItem, bVal ? "true" : "false");
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue2(const char * cSection, const char * cItem, const char * cVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		//int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %s", cItem, cVal);
		//if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		//else
		csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const char * cVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %s", cItem, cVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else
			csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const CStr cVal)
{
	return SetValue(cSection, cItem, cVal.GetString());
}

bool CIni::SetValue(const char * cSection, const char * cItem, const double dbVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %f", cItem, dbVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const float fVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %f", cItem, fVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const long lVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %d", cItem, lVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const int iVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %d", cItem, iVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetValue(const char * cSection, const char * cItem, const unsigned int iVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx = FindItem(idx+1, cItem, csVal);
		csVal.Format("%s = %u", cItem, iVal);
		if (iIdx >= 0) csList.SetAt(iIdx, csVal);
		else csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

bool CIni::SetMultiValue(const char * cSection, const char * cItem, const char * cVal)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		int iIdx =idx;
		while(iIdx!=-1)
		{
			idx = iIdx;
			iIdx = FindItem(iIdx+1, cItem, csVal);
		}
		csVal.Format("%s = %s", cItem, cVal);
		csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}



bool CIni::GetValue(const char * cSection, const char * cItem, bool &bVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			if (csVal.Find("true") >= 0) bVal = true; else bVal = false;
			return true;
		}
	}
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, CStr &cVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		if (FindItem(idx+1, cItem, cVal) > 0)
			return true;
	}
	cVal.Empty();
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, double &dbVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			dbVal = (double)atof(csVal);
			return true;
		}
	}
	dbVal =0;
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, float &fVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			fVal = (float) atof(csVal);
			return true;
		}
	}
	fVal =0;
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, long &lVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			lVal = (long) atol(csVal);
			return true;
		}
	}
	lVal = 0;
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, int &iVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			iVal = (int) atoi(csVal);
			return true;
		}
	}
	iVal = 0;
	return false;
}

bool CIni::GetValue(const char * cSection, const char * cItem, unsigned int &iVal)
{
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		if (FindItem(idx+1, cItem, csVal) > 0)
		{
			iVal = (unsigned int)atoi(csVal);
			return true;
		}
	}
	iVal = 0;
	return false;
}

int CIni::GetFirstMultiValue(const char * cSection, const char * cItem, CStr &cVal)
{
	cVal.Empty();
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		idx = FindItem(idx+1, cItem, cVal);
	}
	return idx;
}

int CIni::GetNextMultiValue(int iItem,const char * cItem, CStr &cVal)
{
	return FindItem(iItem+1, cItem, cVal);
}

void CIni::GetSection(const int iSection,CStr &csVal)
{
	csVal=*(csList.GetAt(iSection));
	csVal.AllTrim();
	csVal.RemoveLeft(1);
    csVal.RemoveRight(1);
}

/*
bool CIni::HandleDWordArrayIP(bool bGet, const char * cSection, const char * cItem, CDWordArray& dwArray)
{
	if(bGet)
	{
		CStr str;
		int  pos;
		
		dwArray.RemoveAll();
		pos = GetFirstMultiValue(cSection,cItem,str);
		if(pos != -1)
			dwArray.Add(inet_addr(str.GetString()));  
		while((pos = GetNextMultiValue(pos,cItem,str)) != -1)
			dwArray.Add(inet_addr(str.GetString())); 
		
#ifdef _TRACE_CONFIG
		TRACE("HandleMultiString begin\n");
		for( int loop = 0 ; loop < dwArray.GetSize() ; loop++ )
			TRACE("%ul\n",dwArray.GetAt(loop));
		TRACE("HandleMultiString end\n\n");
#endif //_TRACE_CONFIG
	}
	else
	{
		RemoveMultiItem(cSection,cItem);
		
		in_addr addr;
		for(int pos = 0; pos < dwArray.GetSize(); pos++)
		{
			addr.S_un.S_addr = dwArray.GetAt(pos);
			if(!SetMultiValue(cSection,cItem,inet_ntoa(addr)))
				return false;
		}
	}
	
	return true;
}*/

#if 0
bool CIni::HandleDWordArray(bool bGet, const char * cSection, const char * cItem, CDWordArray& dwArray)
{
	if(bGet)
	{
		CStr str;
		int  pos;
		
		dwArray.RemoveAll();
		pos = GetFirstMultiValue(cSection,cItem,str);
		if(pos != -1)
			dwArray.Add(atoi(str.GetString()));  
		while((pos = GetNextMultiValue(pos,cItem,str)) != -1)
			dwArray.Add(atoi(str.GetString())); 
/*		
#ifdef _TRACE_CONFIG
		TRACE("HandleMultiString begin\n");
		for( int loop = 0 ; loop < dwArray.GetSize() ; loop++ )
			TRACE("%ul\n",dwArray.GetAt(loop));
		TRACE("HandleMultiString end\n\n");
#endif //_TRACE_CONFIG
*/
	}
	else
	{
		RemoveMultiItem(cSection,cItem);
		
        CStr str;
		for(int pos = 0; pos < dwArray.GetSize(); pos++)
		{
			str.Format("%u",dwArray.GetAt(pos));
			if(!SetMultiValue(cSection,cItem,str.GetString()) )
				return false;
		}
	}
	
	return true;
}
#endif

#if 0
bool CIni::HandleStringArray(bool bGet, const char * cSection, const char * cItem, CStringArray& szArray)
{
	if(bGet)
	{
		CStr str;
		int  pos ;
		
		szArray.RemoveAll();
		pos = GetFirstMultiValue(cSection,cItem,str);
		if(pos != -1)
			szArray.Add(str.GetString());
		while((pos = GetNextMultiValue(pos,cItem,str)) != -1)
			szArray.Add(str.GetString());
/*		
#ifdef _TRACE_CONFIG
		TRACE("HandleMultiString begin\n");
		for( int loop = 0 ; loop < szArray.GetSize() ; loop++ )
			TRACE("%s\n",szArray.GetAt(loop));
		TRACE("HandleMultiString end\n\n");
#endif //_TRACE_CONFIG
*/
	}
	else
	{
		RemoveMultiItem(cSection,cItem);
		
		for(int pos= 0; pos < szArray.GetSize(); pos++)
			if(!SetMultiValue(cSection,cItem,szArray.GetAt(pos)))
				return false;
	}
	return true;
}
#endif

bool CIni::HandleStringArray(bool bGet, const char * cSection, const char * cItem, CStrArray& szArray, bool bRemoveAll)
{
	if(bGet)
	{
		CStr str;
		int  pos ;
		
		szArray.Close();
		pos = GetFirstMultiValue(cSection,cItem,str);
		if(pos != -1)
			szArray.Add(str);
		else
		{
			//should return ??  maybe. this is a small problem
		}
		while((pos = GetNextMultiValue(pos,cItem,str)) != -1)
			szArray.Add(str);
	}
	else
	{
		if (bRemoveAll) 
			RemoveMultiItem(cSection,cItem);
		for(int pos= 0; pos < szArray.GetSize(); pos++)
			if(!SetMultiValue(cSection,cItem,szArray.GetAt(pos)->GetString()))
				return false;
	}
	return true;
}

bool CIni::HandleStringArrayEx (bool bGet, const char* cSection, const char* cItem, CStrArray& szArray,CStrArray &csAryClueID, bool bRemoveAll)
{
	//add by stf

//	char strClueId[32];
	if(bGet)
	{
		//CString str;
		CStr str;
		int  pos ;
		//unsigned int nClueID;
		CStr strClueID;
		
		if (bRemoveAll)	// add by syc
		{
			szArray.RemoveAll();
			csAryClueID.RemoveAll();
			//dwClueID.RemoveAll();
		}
		pos = GetFirstMultiValueEx(cSection,cItem,str,strClueID);
		if(pos != -1)
		{
			szArray.Add(str);
			//sprintf(strClueId,"%d",nClueID);
			csAryClueID.Add(strClueID);
			//csAryClueID.Add(nClueID);
			//dwClueID.Add(nClueID);
		}
		
		while((pos = GetNextMultiValueEx(pos,cItem,str,strClueID )) != -1)
		{
			szArray.Add(str);
			//sprintf(strClueId,"%d",nClueID);
			csAryClueID.Add(strClueID);
			//dwClueID.Add(nClueID);
		}
		
//	for( int loop = 0 ; loop < szArray.GetSize() ; loop++ )
//		DEBUGDUMPVAR(2,"strArray =%s",szArray.GetAt(loop)->GetString());

		
#ifdef _TRACE_CONFIG
		TRACE("HandleMultiString begin\n");
		for( int loop = 0 ; loop < szArray.GetSize() ; loop++ )
			TRACE("%s,,%ul\n",szArray.GetAt(loop),dwClueID.GetAt(loop));
		TRACE("HandleMultiString end\n\n");
#endif //_TRACE_CONFIG
	}
	else
	{
		if (bRemoveAll)	// add by syc
			RemoveMultiItem(cSection,cItem);
		
		char buf[20];
		memset(buf,0,sizeof(buf));
		
		for(int pos= 0; pos < szArray.GetSize(); pos++)
		{
			//itoa(dwClueID.GetAt(pos),buf,10);
			//itoa(csAryClueID.GetAt(pos),buf,10);
			//if(!SetMultiValueEx(cSection,cItem,(szArray.GetAt(pos)).GetBuffer(0),buf))
			if(!SetMultiValueEx(cSection,cItem,(szArray.GetAt(pos)->GetString()),buf))
				return false;		
		}
		
	}
	return true;
}


bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, bool &bVal)
{
	if(bGet)
		return GetValue(cSection,cItem,bVal);
	else
		return SetValue(cSection,cItem,bVal);
}

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, double &dbVal)
{
	if(bGet)
		return GetValue(cSection,cItem,dbVal);
	else
		return SetValue(cSection,cItem,dbVal);
}

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, float &fVal)
{
	if(bGet)
		return GetValue(cSection,cItem,fVal);
	else
		return SetValue(cSection,cItem,fVal);
}

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, long &lVal)
{
	if(bGet)
		return GetValue(cSection,cItem,lVal);
	else
		return SetValue(cSection,cItem,lVal);
}

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, int &iVal)
{
	if(bGet)
		return GetValue(cSection,cItem,iVal);
	else
		return SetValue(cSection,cItem,iVal);
}

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, unsigned int &iVal)
{
	if(bGet)
		return GetValue(cSection,cItem,iVal);
	else
		return SetValue(cSection,cItem,iVal);
}

#if 0
bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, CString &iVal)
{
	CStr str(iVal);
	if(bGet)
	{
		bool bRtn = GetValue(cSection,cItem,str);
		iVal = str.GetString();
		return bRtn;
	}
	else
		return SetValue(cSection,cItem,str);
}
#endif

bool CIni::HandleSimpleType(bool bGet, const char * cSection, const char * cItem, CStr &iVal)
{
	CStr str(iVal);
	if(bGet)
	{
		bool bRtn = GetValue(cSection,cItem,str);
		iVal = str.GetString();
		return bRtn;
	}
	else
		return SetValue(cSection,cItem,str);
}

//add by stf
int CIni::GetFirstMultiValueEx(const char* cSection, const char* cItem, 
							   CStr &cVal, unsigned int &nClueID)
{
	cVal.Empty();
	nClueID = 0;
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		CStr csClueID;
		idx = FindItemEx(idx+1, cItem, cVal, csClueID);
		nClueID = atoi(csClueID);
	}
	
	return idx;
}

//add by stf
int CIni::GetFirstMultiValueEx(const char* cSection, const char* cItem, 
							   CStr &cVal, CStr &cClueID)
{
	cVal.Empty();
	int idx = FindSection(cSection);
	if (idx >= 0)
	{
		idx = FindItemEx(idx+1, cItem, cVal, cClueID);
	}
	
	return idx;
}


bool CIni::SetMultiValueEx(const char* cSection, const char* cItem, const char* cVal,  const char*cClueID)
{
	int idx = InsertSection(cSection);
	if (idx >= 0)
	{
		CStr csVal;
		CStr csClueID;
		int iIdx =idx;
		while(iIdx!=-1)
		{
			idx = iIdx;
			iIdx = FindItemEx(iIdx+1, cItem, csVal,csClueID);
		}
		csVal.Format("%s = %s,,%s", cItem, cVal,cClueID);
		csList.InsertAt(idx+1, csVal);
		return true;
	}
	return false;
}

int  CIni::GetNextMultiValueEx(int iItem, const char* cItem,CStr &cVal, unsigned int &nClueID)
{
	CStr csClueID;
	int idx = FindItemEx(iItem+1, cItem, cVal,csClueID);
	nClueID = atoi(csClueID);
	return idx;
}

int  CIni::GetNextMultiValueEx(int iItem, const char* cItem,CStr &cVal, CStr &cClueID)
{
	int idx = FindItemEx(iItem+1, cItem, cVal, cClueID);
	return idx;
}

int	 CIni::FindItemEx(const int iSection, const char* cItem, CStr &csVal,CStr &csClueID)
{
	assert(iSection >= 0);
	assert(cItem);
	
	CStr csItem(cItem),csLook,csTmp,csValTmp;
	csItem += " = ";
	int iLen = csItem.GetLength();
	
	int nIndex = 0;
	int t, max = csList.GetSize();
	
	for (t = iSection; t < max; t++)
	{
		if(IsSection(t))
			return -1;
		
		//csLook = csList.GetAt(t);
		csLook = *(csList.GetAt(t));
		if(csLook.GetAt(0)==';')
			continue;
		
		if (csLook.GetLength() >= iLen)
		{
			//csTmp = csLook.Left(iLen);
			csLook.GetLeft(iLen,csTmp);
			if ( csTmp== csItem) 
			{   
				if (csLook.GetLength() == iLen) 
				{
					csVal = "";
					csClueID = "";
				}
				else 
				{
					//csValTmp = csLook.Mid(iLen);
					csLook.GetMiddle(iLen,csLook.GetLength(),csValTmp);
					//nIndex = csValTmp.Find(",,");
					//nIndex = ReverseFind(csValTmp, ",,");
					nIndex = csValTmp.ReverseFind(",,",2);
					//ReverseFind
					if (nIndex != -1)
					{
						//csVal = csValTmp.Left(nIndex);
						//csClueID = csValTmp.Mid(nIndex+2);
						csValTmp.GetLeft(nIndex,csVal);
						csValTmp.GetMiddle(nIndex+2,csValTmp.GetLength(),csClueID);
						csVal.LTrim();
						csVal.RTrim();
						csClueID.LTrim();
						csClueID.RTrim();
					}
					else
					{
						csVal = csValTmp;
						csClueID = "";
					}
				}
				return t;
			}
		}
	}
	return -1;
}
