/*=========================================================
*	File name	��	allocfix.h
*	Authored by	��	DAIHW
*	Date		��	2008-1-21 21:03:07
*	Description	��	declarations for fixed block allocator
*
*	Modify  	��	
*=========================================================*/
#ifndef __ALLOCFIX_H__
#define __ALLOCFIX_H__

#include "lock.h"
#include "npr_identify.h"

/////////////////////////////////////////////////////////////////////////////
// CCluster

struct CCluster     // warning variable length structure
{
	CCluster* pNext;
	
	static CCluster* Create(CCluster*& head, UINT32 nMax, UINT32 cbElement);
	// free this one and links
	void FreeDataChain();       

	void* data() { return this+1; }	
};

/////////////////////////////////////////////////////////////////////////////
// CAllocFixed

class CAllocFixed
{
// Constructors
public:
	CAllocFixed(UINT32 nAllocSize, UINT32 nAllocNum = 64);

// Attributes
	UINT32 GetAllocSize() { return m_nAllocSize; }

// Operations
public:
	void* Alloc();  // return a chunk of memory of nAllocSize
	void Free(void* p); // free chunk of memory returned from Alloc
	void FreeAll(); // free everything allocated from this allocator
	UINT32 m_nAllocBlockCount ;

	//2010-11-26 jingliang �ڴ�ͳ��
	UINT64 GetAllocMem()
	{
		UINT64 ret;
		m_Protect.Lock();
		ret = m_nAllocBlockCount * m_nAllocSize;
		m_Protect.Unlock();
		return ret;
	}
	void * GetNodeNext()
	{
		return m_pNodeFree;
	}
	void CheckNodeNext();

// Implementation
public:
	~CAllocFixed();

protected:
	struct CNode
	{
		CNode* pNext;   // only valid when in free list
	};

	UINT32 m_nAllocSize;  // size of each block from Alloc
	UINT32 m_nBlockSize;  // number of blocks to get at a time
	CCluster* m_pBlocks;   // linked list of blocks (is nBlocks*nAllocSize)
	CNode* m_pNodeFree; // first free node (NULL if no free nodes)
	CLock m_Protect;
};

#endif // __ALLOCFIX_H__
