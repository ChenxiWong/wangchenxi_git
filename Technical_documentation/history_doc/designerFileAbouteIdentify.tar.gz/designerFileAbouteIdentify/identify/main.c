// Last Update:2016-09-09 15:30:30
/**
 * @file main.cpp
 * @brief 
 * @author wangchenxi
 * @version 0.1.00
 * @date 2016-09-09
*/
#define DEBUG
#include <stdio.h>
#include "protoclassify.h"
#include "strarray.h"
#include "mystr.h"
#include <iostream>
#include <fstream>
#include "ini.h"
#include "npr_identify.h"
using namespace std;


static int php_htoi(char *s)  
{  
    int value;  
    int c;  

    c = ((unsigned char *)s)[0];  
    if (isupper(c))  
        c = tolower(c);  
    value = (c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10) * 16;  

    c = ((unsigned char *)s)[1];  
    if (isupper(c))  
        c = tolower(c);  
    value += c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10;  

    return (value);
}
//url解码函数:utf-8类型
string urldecode(string &str_source)
{
    char const *in_str = str_source.c_str();  
    int in_str_len = strlen(in_str);  
    int out_str_len = 0;  
    string out_str;  
    char *str;  

    str = strdup(in_str);  
    char *dest = str;  
    char *data = str;  
    while (in_str_len--)
    {
        if (*data == '+') 
        {
            *dest = ' ';  
        }
        else if (*data == '%' && in_str_len >= 2 && isxdigit((int) *(data + 1))   
                && isxdigit((int) *(data + 2))) 
        {
            *dest = (char) php_htoi(data+1);  
            data += 2;  
            in_str_len -= 2;  
        }
        else 
        {
            *dest = *data;  
        }
        data++;
        dest++;
    }
    *dest = '\0';  
    out_str_len =  dest - str;  
    out_str = str;  
    free(str);  
    return out_str;  
}

int main(int argc, char* argv[])
{
    const char* c_tmp = NULL;
    c_tmp = argv[1] == NULL?"%47%45%54":argv[1];
    /*if(argv[1]== NULL)
    {
        c_tmp ="%47%45%54";
    }
    else
    {
        c_tmp = argv[1];
    }*/
    string str_tmp(c_tmp);
    str_tmp = urldecode(str_tmp);
    cout<<str_tmp<<endl;
    char* pc = const_cast<char*>(str_tmp.c_str());
    NprIdentify test_nprIdentify("./protoproperties.ini", "./version2.conf");
    IPv4TransportAddr test_ip_client;
    test_ip_client.nIP = 0xAABBCCFF;
    test_ip_client.nPort = 80;
    IPv4TransportAddr test_ip_server;
    test_ip_server.nIP = 0xAABBCCFF;
    test_ip_server.nPort = 80;
    IPv4ConnectAddr test_ipv4;
    test_ipv4.Client = test_ip_client;
    test_ipv4.Server = test_ip_server;
    test_ipv4.nProtocol = 0;
    ProtoId test_protoid;
    if(test_nprIdentify.FindProto( TCP_PROTOCOL, test_ipv4, pc, str_tmp.size(), test_protoid))
    {
        DBGCODE( cout<<" PID = "<<test_protoid.PID<<endl
            <<" SID = "<<test_protoid.SID<<endl
            <<" TID = "<<test_protoid.TID<<endl
            <<" nCreateConn = "<<test_protoid.nCreateConn<<endl;
        cout<<" protocol_name = "<<string(test_nprIdentify.GetProtoStruct(test_protoid.PID)->szName)<<endl; );
    }else
    {
        DBGCODE( cout<<"hello, world!--error!"<<endl;);
    }
}
