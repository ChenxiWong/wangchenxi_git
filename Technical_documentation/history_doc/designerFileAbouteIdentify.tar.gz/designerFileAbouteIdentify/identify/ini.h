#ifndef _INI_H_
#define _INI_H_

#include "mystr.h"
#include "strarray.h"
#include <sys/stat.h>
#include <sys/types.h>

#undef MAX_PATH
#define MAX_PATH   255

class CIni  
{
public:
	CIni();
	virtual ~CIni();
	
	void Close();
	bool Save(const char * cFileName, bool bIsWin=false);
	bool Load(const char * cFileName);
	bool CheckUpdate();
	
public:
	void RemoveMultiItem(const char * cSection, const char * cItem);
	bool RemoveAll();
	int	 FindItem(const int iSection, const char * cItem, CStr &csVal);
	
	bool RemoveSection(const char * cSection);
	bool RemoveItem2(const char * cSection, const char * cItem, CStr &csVal);
	bool IsSection(const int iSection);
	int  InsertSection(const char * cSection);
	int  FindSection(const char * cSection);
	int  FindSection2(void);
	void GetSection(const int iSection,CStr &csVal);
	
	bool SetMultiValue(const char * cSection, const char * cItem, const char * cVal);
	bool SetValue(const char * cSection, const char * cItem, const bool bVal);
	bool SetValue2(const char * cSection, const char * cItem, const char * cVal);
	bool SetValue(const char * cSection, const char * cItem, const char * cVal);
	bool SetValue(const char * cSection, const char * cItem, const double dbVal);
	bool SetValue(const char * cSection, const char * cItem, const float fVal);
	bool SetValue(const char * cSection, const char * cItem, const long lVal);
	bool SetValue(const char * cSection, const char * cItem, const int iVal);
	bool SetValue(const char * cSection, const char * cItem, const CStr csVal);
	bool SetValue(const char * cSection, const char * cItem, const unsigned int iVal);
	
	int GetFirstMultiValue(const char * cSection, const char * cItem, CStr &cVal);
	int GetNextMultiValue(int iItem, const char * cItem,CStr &cVal);

	int GetFirstMultiValueEx(const char* cSection, const char* cItem, CStr &cVal, CStr &cClueID);
	int  GetNextMultiValueEx(int iItem, const char* cItem,CStr &cVal, CStr &cClueID);
	//add by stf
	int  GetFirstMultiValueEx(const char* cSection, const char* cItem, CStr &cVal, unsigned int &nClueID);
	int  GetNextMultiValueEx(int iItem, const char* cItem,CStr &cVal, unsigned int &nClueID);
	bool SetMultiValueEx(const char* cSection, const char* cItem, const char* cVal,  const char*cClueID);
	int	 FindItemEx(const int iSection, const char* cItem, CStr &csVal,CStr &csClueID);
	//int	 FindItemEx(const int iSection, const char* cItem, CString &csVal,CString &csClueID);
	//add end
	
	bool GetValue(const char * cSection, const char * cItem, bool &bVal);
	bool GetValue(const char * cSection, const char * cItem, CStr &cVal);
	bool GetValue(const char * cSection, const char * cItem, double &dbVal);
	bool GetValue(const char * cSection, const char * cItem, float &fVal);
	bool GetValue(const char * cSection, const char * cItem, long &lVal);
	bool GetValue(const char * cSection, const char * cItem, int &iVal);
	bool GetValue(const char * cSection, const char * cItem, unsigned int &iVal);

	//bool HandleDWordArrayIP(bool bGet, const char * cSection, const char * cItem, CDWordArray& dwArray);
	//bool HandleDWordArray(bool bGet, const char * cSection, const char * cItem, CDWordArray& dwArray);
	//bool HandleStringArray(bool bGet, const char * cSection, const char * cItem, CStringArray& szArray);
	bool HandleStringArray(bool bGet, const char * cSection, const char * cItem, CStrArray& szArray, bool bRemoveAll=false);
	bool HandleStringArrayEx (bool bGet, const char* cSection, const char* cItem, CStrArray& szArray,CStrArray &csAryClueID, bool bRemoveAll = true);
	

	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, bool &bVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, double &dbVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, float &fVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, long &lVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, int &iVal);
	//bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, CString &iVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, CStr &iVal);
	bool HandleSimpleType(bool bGet, const char * cSection, const char * cItem, unsigned int &iVal);
	
private:
	CStrArray	csList;
	CStr csLineEnd;
	int findposition;
	char m_szFileName[MAX_PATH];
	struct stat m_LastFileStat;
};


#endif // _INI_H_

