/*=========================================================
*	File name	��	CAppBase.cpp
*	Authored by	��	xuxinyao
*	Date		��	2002-1-30 1:57:27
*	Description	��	
*
*	Modify  	��	zjk 2006-6-6
*=========================================================*/
#include "npr_identify.h"
//#include "findnum.h"
//#include "cluedef.h"
//#include "outputdef.h"


//#include "service/servicebase.h"
#include "appbase.h"
//#include "decode/a11datapool.h"
//#include "decode/adsldecode/pppoe.h"
//#include "decode/workthread.h"

//#include "main/transformerapp.h"
//#include "net/network_ctrl.h"
//#include "net/radius_table.h"
//#include "gtp/gtp_decode.h"
//#include "gtp/pdp.h"
//#include "gtp/mhash.h"
//#include "gtp/gtp2_decode.h"
//#include "gtp/pdn.h"
//#include "gtp/gtp2_mhash.h"
//#include "s1ap/s1ap_decode.h"
//#include "s1ap/s1ap_hash_interface.h"
//#include "global/s1mme_interface.h"
//#include "common/msgq-common.h"


//����ģ���ID��ѯģ�����ֵĺ���ָ��	
//PFGETNAMEBYID CAppBase::m_pfnGetNameByID = NULL;
//����ģ������ֲ�ѯģ��ID�ĺ���ָ��
//PFGETIDBYNAME CAppBase::m_pfnGetIDByName = NULL;
//�����µ����������������DNSЭ������з��ֵ�ͻ��������IP��ַ���ӵ�DNSPool�еĺ���ָ��	
PFADDDNSCONNECT CAppBase::m_pfnAddDNSConnect = NULL;

// support query otherid. by rongjie, 2007/12/12
UINT32 CAppBase::m_nOtherPID = 255;

//CPhonePool	CAppBase::m_PhonePool;	
//CA11DataPool	CAppBase::m_A11DataPool;
UINT32 g_nCurAssociaRate = 0;

//**********************
//	function name: CAppBase
//	function :���캯��
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************

CAppBase::CAppBase()
{
	/*
	m_bIsDestroy = false;	//��־�Ƿ�ɾ���˶���		
	m_bProcess = true;		//�Ƿ������������������		
	m_nSeqNum = 0;		    //����TCP���к�		
	m_bClientToSer = true;	//���ķ����Ƿ�ӿͻ�����������		
	m_bPass = false;		//���˱�ʶ,��־�Ƿ�����б�		
	m_FinFlag = 0; 	//Tcp���ӹرձ�ʶ�����λ��ʶ�Ƿ��յ�Server����Fin�����ε�λ��ʶ�Ƿ��յ�Client����Fin��		
	m_nObjectID = 0;
	m_bHasAckFlag = false;
	m_nObjectSID = 0; //add by xjh
	m_bIsProcessEnd = true;	
	memset(&m_PackInfo,0x0,sizeof(m_PackInfo));
	memset(&m_BaseInfo,0x0,sizeof(m_BaseInfo));
	m_MatchingResult.AppResult.clear();
	m_MatchingResult.LinkResult.clear();
	m_MatchingResult.RelatedResult.clear();
	m_MatchingResult.bTrust = false ;
	
	//add by lzr
	m_bIsHitSpecialObjectClue = false;
//	m_bIsSpecialObjectAppAlreadyFiltered = false;
	m_pSpecialObjectMemlink = NULL;
	m_SpecialObjectMatchingResult.RelatedResult.clear();
	m_SpecialObjectMatchingResult.AppResult.clear();
	m_SpecialObjectMatchingResult.LinkResult.clear();

	//add by lzr 2009-09-11 for rpc
	hasHitSpecialAppClue = false;
	hasSendToRPCServer = false;
	specialObjectRelateTime = 0;

	m_bIsInit = false ;
	*/
}


//**********************
//	function name: CAppBase(CAppBase &AppBaseObj)
//	function :���캯��
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************
CAppBase::CAppBase(CAppBase &AppBaseObj)
{
	(void)AppBaseObj;
	/*
	if (g_pIdc->m_bIsOpenServStat)
	{
		//����ͳ�ƿ��ش�
		if ((AppBaseObj.m_nObjectID > 1 && AppBaseObj.m_nObjectID < 7 ) || AppBaseObj.m_nObjectID == 9)
		{
			//idc����ͳ�Ƶ�httpЭ����ͳ��
			static SERV_STR tempServ;
			tempServ.appProto = AppBaseObj.m_nObjectID;
			tempServ.sip = AppBaseObj.m_BaseInfo.ConnAddr.Server.nIP;
			tempServ.sport = AppBaseObj.m_BaseInfo.ConnAddr.Server.nPort;
			tempServ.cip = AppBaseObj.m_BaseInfo.ConnAddr.Client.nIP;
			tempServ.cport = AppBaseObj.m_BaseInfo.ConnAddr.Client.nPort;
			tempServ.nBytes = 0;
			tempServ.nPkts = 0;
			tempServ.time = g_nCurTime;
			memset(tempServ.str , 0 , 256);
			int templen = AppBaseObj.GetUrl().GetLength();	
			templen = templen>255?255:templen;
			templen =  MultiByteToUTF8( "gbk", AppBaseObj.GetUrl().GetString(), templen, tempServ.str, 255);
			templen = templen>255?255:templen;
			if (templen > 1)
			{
				tempServ.str[templen] = '\0';
				g_pIdc->Add_ServStr(&tempServ);
			}
		}
	}
	m_bIsDestroy = false;	//��־�Ƿ�ɾ���˶���		
	m_bProcess = true;		//�Ƿ������������������		
	m_nSeqNum = 0;		    //����TCP���к�		
	m_bClientToSer = true;	//���ķ����Ƿ�ӿͻ�����������		
	m_bPass = false;		//���˱�ʶ,��־�Ƿ�����б�		
	m_FinFlag = 0; 	//Tcp���ӹرձ�ʶ�����λ��ʶ�Ƿ��յ�Server����Fin�����ε�λ��ʶ�Ƿ��յ�Client����Fin��		
	m_nObjectID = 0;
	m_bHasAckFlag = false;
	m_nObjectSID = 0; //add by xjh
	m_bIsProcessEnd = true;	

	memset(&m_PackInfo,0x0,sizeof(m_PackInfo));
	memcpy(&m_BaseInfo,&AppBaseObj.m_BaseInfo,sizeof(m_BaseInfo));
	m_bPass = AppBaseObj.m_bPass;
	m_bIsDestroy = AppBaseObj.m_bIsDestroy;
	m_nSeqNum = AppBaseObj.m_nSeqNum;
	m_bClientToSer = AppBaseObj.m_bClientToSer;
	m_nObjectID = AppBaseObj.m_nObjectID;
	m_MatchingResult.AppResult = AppBaseObj.m_MatchingResult.AppResult;
	m_MatchingResult.LinkResult = AppBaseObj.m_MatchingResult.LinkResult;
	m_MatchingResult.RelatedResult = AppBaseObj.m_MatchingResult.RelatedResult;
	m_MatchingResult.nType = AppBaseObj.m_MatchingResult.nType;
	m_MatchingResult.bTrust = AppBaseObj.m_MatchingResult.bTrust ;

	//add by lzr
	m_SpecialObjectMatchingResult.AppResult = AppBaseObj.m_SpecialObjectMatchingResult.AppResult;
	m_SpecialObjectMatchingResult.RelatedResult = AppBaseObj.m_SpecialObjectMatchingResult.RelatedResult;
	m_SpecialObjectMatchingResult.LinkResult = AppBaseObj.m_SpecialObjectMatchingResult.LinkResult;
	m_bIsHitSpecialObjectClue = AppBaseObj.m_bIsHitSpecialObjectClue;

	//add by lzr 2009-09-11 for rpc
	hasHitSpecialAppClue = AppBaseObj.hasHitSpecialAppClue;
	hasSendToRPCServer = AppBaseObj.hasSendToRPCServer;
	
//	m_bIsSpecialObjectAppAlreadyFiltered = AppBaseObj.m_bIsSpecialObjectAppAlreadyFiltered;

	if(AppBaseObj.m_pSpecialObjectMemlink != NULL)
	{
		m_pSpecialObjectMemlink = new memlink();
		MEMLINK *head = AppBaseObj.m_pSpecialObjectMemlink->Head();
		while(head != NULL)
		{
			m_pSpecialObjectMemlink->Append(head->pBuffer,head->nBuflen,head->CurTime);
			head = head->next;
		}
	}
	else
	{
		m_pSpecialObjectMemlink = NULL;
	}*/
}
//add by lzr 208-03-18

//**********************
//	function name: ��CAppBase
//	function :��������
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************

CAppBase::~CAppBase()
{
	/*
	memset(&m_PackInfo,0x0,sizeof(m_PackInfo));
	m_MatchingResult.AppResult.clear();
	m_MatchingResult.LinkResult.clear();
	m_MatchingResult.RelatedResult.clear();
//	m_A11DataPool.Close();
	//add by lzr
	//m_SpecialObjectMatchingResult ����ĵײ㡢Ӧ�ò㡢����Э��Ϊvector���ͣ������ֶ����
	if(m_pSpecialObjectMemlink != NULL)
	{
		DataPublic *pub = new DataPublic;	
		memcpy(pub, &m_BaseInfo, sizeof(DataPublic));
		DataOutRaw *dataout = new DataOutRaw(OUTPUTRAW_TYPE_SPECIAL_OBJECT, SPECIAL_OBJECT_FAKE_PROTOCOL_ID,SPECIAL_OBJECT_FAKE_PROTOCOL_NAME, pub, m_pSpecialObjectMemlink, true, NULL);
		std::vector<OutputMatchingResult> *pServiceResult = new std::vector<OutputMatchingResult>;
		if(pServiceResult == NULL)
		{
			DUMPERRLOG("error", 0, "outputraw", "CAppBase", "SpecialObjectCapOutPut", "new std::vector<MatchingResult> failed");
			delete pub;
			delete dataout;
			return;
		}
		UINT32 client_ip = dataout->pPublicInfo->ConnAddr.Client.nIP;
		//CServiceBase::DispenseClues(dataout->nProtoID, m_SpecialObjectMatchingResult, pServiceResult, client_ip, IP_TYPE_NORMAL, false);
		//������ʱ�������ȷ��Э��id�����������ض�����ͳһ�ļٵ�Э��id
		CServiceBase::DispenseClues(m_nObjectID, m_SpecialObjectMatchingResult, pServiceResult, client_ip, IP_TYPE_NORMAL, false);
		dataout->pFitID = pServiceResult;
		g_pOutputRaw->AddDataToQueue(dataout);
		m_pSpecialObjectMemlink = NULL;
	}
	*/
}

//**********************
//	function name: EspDataProcess
//	function :������������
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************

bool CAppBase::EspDataProcess()
{
	return true;
}



//**********************
//	function name: Init
//	function :��ʼ������
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************
inline void CAppBase::Init(IPv4ConnectAddr& ConnectAddress,const UCHAR* pMAC, const IPv4TransportAddr& SrcAddr)
{
	(void)ConnectAddress;
	(void)pMAC;
	(void)SrcAddr;
}

//**********************
//	function name: Init
//	function :��������
//	return:	
//	create time:
//	author:
//	modify record:
//	modify time:
//************************
/*
bool CAppBase::GetClues(MatchingResult & pMatchingResult)
{
	pMatchingResult.LinkResult = m_MatchingResult.LinkResult;
	return true;
}
*/

extern uint64_t g_s11_statistic[];

//static UINT32 u32FoundStat = 0;
//static UINT32 u32GtpuNoStat = 0;
//static UINT32 u32OldTimeStamp = g_nCurTime;

void CAppBase::InitBase(IPv4ConnectAddr& ConnectAddress,const UCHAR* pMAC, 
	const IPv4TransportAddr& SrcAddr, DoubleIPv4ConnectAddr & ConnectAddresscdma, 
	UINT32 & Grekeycdma, UINT16 & nVLanId, UINT16 & nSessionId , 
	IPv6TunnelData&  TunnelAddress, UINT32 nDataType)
{
	(void)ConnectAddress;
	(void)pMAC;
	(void)SrcAddr;
	
	(void)ConnectAddresscdma;
	
	(void)Grekeycdma;
	(void)nVLanId;
	(void)nSessionId;
	
	(void)TunnelAddress;
	(void)nDataType;
	/*
	int result = 0 ;
	radius_info_t lradius_info;
	UINT16 port_interger  = g_portInterger;
    static UINT32 u32QueryTimes = 0;
    int i = 0;
    int j = 0;
    struct natHashInfo struNatTemp; 

	memset(&lradius_info, 0, sizeof(lradius_info));
	memset(&struNatTemp, 0, sizeof(struct natHashInfo));

	m_BaseInfo.CdmaInfo.nDataSource = g_DataSource ;
	m_BaseInfo.ConnAddr.Client = ConnectAddress.Client;
	m_BaseInfo.ConnAddr.Server = ConnectAddress.Server;
	m_BaseInfo.ConnAddr.nProtocol = ConnectAddress.nProtocol;
	m_BaseInfo.nVLanId = nVLanId ;
	//�������ݵ�����IP����������ֶ����====start
	m_BaseInfo.CdmaInfo.nPcfIp = ConnectAddresscdma.SubConnAddr.Client.nIP ;
	m_BaseInfo.CdmaInfo.nPdsnIp = ConnectAddresscdma.SubConnAddr.Server.nIP ;
	//====end========
	SetClientMac(pMAC,SrcAddr);
	//�������Ӷ�Ӧ�ķ������˵�MAC
	SetServerMac(pMAC,SrcAddr);

	
       m_BaseInfo.nIPv6DataType = nDataType;
	if ( IPv6_TYPE_4OVER6_DIRECT == nDataType )
	{
		//m_BaseInfo IPv6 ������ַ
		m_BaseInfo.TunnelAddrIPv6.nIPType = TunnelAddress.nIPType;
		m_BaseInfo.TunnelAddrIPv6.addr_ipv4.nSrcIP = TunnelAddress.addr_ipv4.nSrcIP;
		m_BaseInfo.TunnelAddrIPv6.addr_ipv4.nDstIP = TunnelAddress.addr_ipv4.nDstIP;
		memcpy(m_BaseInfo.TunnelAddrIPv6.addr_ipv6.aSrcIPv6, TunnelAddress.addr_ipv6.aSrcIPv6, 16);
		memcpy(m_BaseInfo.TunnelAddrIPv6.addr_ipv6.aDstIPv6, TunnelAddress.addr_ipv6.aDstIPv6, 16);
		
	}
       
	if( g_DataSource == ADSL_PPPoE_IP_NET )	
	{
		
		if ( g_net_module != NULL )
		{
			result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Client.nIP, g_portInterger,&lradius_info, m_BaseInfo.ConnAddr.Client.nPort) ;
			if ( result != 0 )
			{
				result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Server.nIP, g_portInterger, &lradius_info, m_BaseInfo.ConnAddr.Server.nPort) ;
			}
			if ( result != 0 )
			{
				if(m_BaseInfo.ConnAddr.Client.nPort  >= 1024)
					port_interger = (m_BaseInfo.ConnAddr.Client.nPort - 1024)/4096;
				result =  g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Client.nIP, port_interger,&lradius_info, m_BaseInfo.ConnAddr.Client.nPort) ;
			
				if( result != 0 )
				{
					if(m_BaseInfo.ConnAddr.Server.nPort  >=1024)
						port_interger = (m_BaseInfo.ConnAddr.Server.nPort - 1024)/4096;
					result =  g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Server.nIP, port_interger,&lradius_info, m_BaseInfo.ConnAddr.Server.nPort) ;
				}
			}

			if ( result == 0 )
			{
				strncpy ( m_BaseInfo.szPhonenum, lradius_info.calling_id, CALLING_ID_SIZE ) ;
				strncpy ( m_BaseInfo.szAccount, lradius_info.user_name, USER_NAME_SIZE ) ;
			}
		}
		else
		{
			assert( NULL != CDecodePPPoE::m_pAdsldataPool ) ;
			int nIndex = CDecodePPPoE::m_pAdsldataPool->FindAdslNode( nSessionId, m_BaseInfo.byClientMac, 
					ConnectAddress.Client.nIP, ConnectAddress.Server.nIP ) ;
			STADSLNODE *pAdslNode = CDecodePPPoE::m_pAdsldataPool->GetANode( nIndex ) ;
			if( NULL == pAdslNode )	
			{
				return ;
			}
			int nAdslAccount = strlen(pAdslNode->stAdslData.szAccount) ;
			nAdslAccount = (nAdslAccount > (int)sizeof(m_BaseInfo.szAccount)-1) ? (int)sizeof(m_BaseInfo.szAccount)-1 : nAdslAccount ;
			strncpy(m_BaseInfo.szAccount, pAdslNode->stAdslData.szAccount, nAdslAccount );
			m_BaseInfo.szAccount[nAdslAccount] = '\0' ;
		}
		
		m_MatchingResult.LinkResult.clear(); 
		if (R_SUCCESS_TRUST==CServiceBase::LinkFilter(ConnectAddress,m_MatchingResult,(const char*)m_BaseInfo.byClientMac,
					(const char*)m_BaseInfo.byServerMac,m_nObjectID,
					m_BaseInfo.szAccount ) )
		{
			NoProcess();
		}

	}
	else
	{
		m_MatchingResult.LinkResult.clear(); 
#ifdef _LINZHEN	
		if (  R_SUCCESS_TRUST == CServiceBase::LinkFilter( ConnectAddress,m_MatchingResult,
					(const char*)m_BaseInfo.byClientMac,(const char*)m_BaseInfo.byServerMac,m_nObjectID ) ) 
		{
			NoProcess();
		}
#else
		//����ǰ��������Ͳ���������
		if ( R_SUCCESS_TRUST == CServiceBase::LinkFilter(ConnectAddress,m_MatchingResult,m_nObjectID) ) 
		{
			NoProcess();
		}
#endif
	}
	GetSpecialObjectLinkRelatedHitClues(m_MatchingResult,m_SpecialObjectMatchingResult);//add by lzr

	//add by xudong 2008.5.13
#if 0
	timeval t;
	gettimeofday(&t, NULL);
	UINT64 bf_call = (UINT64)t.tv_sec * 1000000 + (UINT64)t.tv_usec;
#endif

	if(g_TransformerApp.m_pBlockClient)
	{
		if ( m_MatchingResult.LinkResult.size() || m_MatchingResult.RelatedResult.size())
		{
			int nProtoType = ConnectAddress.nProtocol;
			g_TransformerApp.m_pBlockClient->AddBlockAction(nProtoType, &ConnectAddress, &m_MatchingResult, CLUE_TYPE_BOTTOM, NULL, 0);
		}
	}

#if 0
	gettimeofday(&t, NULL);
	UINT64 af_call = (UINT64)t.tv_sec * 1000000 + (UINT64)t.tv_usec;	
	UINT64 interval = af_call - bf_call;

	m_nCount ++ ;
	m_nTimeval += interval;
	if( m_nCount % 50 == 0 )
	{
		printf("CAppBase::InitBase 50 times avarage timeval = %d\n", m_nTimeval / m_nCount );
	}
#endif
	//duxin add 2009-11-05
	if ( g_net_module != NULL )
	{
		g_net_module->check_timeout () ;
	}

	//����radius �ʺţ��绰����
	//duxin add 2008-06-03
	if ( g_DataSource == WIRELESS_CDMA_PPP_NET )
	{
		//����ǵ���ģʽ
		DataA11Node* p = NULL;
		p = m_A11DataPool.FindA11 ( Grekeycdma, &ConnectAddresscdma.SubConnAddr, m_BaseInfo );
		//����֤�����ֶθ�ֵ xjh begain
		if (p != NULL)
		{
			sprintf(m_BaseInfo.szAuthType, "%s", "1020003");
		}
	    //����֤�����ֶθ�ֵ xjh end
		CServiceBase::AppProtoToA11Filter(m_MatchingResult, m_BaseInfo);
		result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Client.nIP, g_portInterger, &lradius_info, m_BaseInfo.ConnAddr.Client.nPort) ;
		if ( result != 0 )
		{
			result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Server.nIP, g_portInterger, &lradius_info, m_BaseInfo.ConnAddr.Server.nPort) ;
		}
		
		//--- add xiaodong 2015-12-9 ---
		if (0 != result)
		{
			result = radiusQuery(m_BaseInfo.ConnAddr.Server.nIP,
									m_BaseInfo.ConnAddr.Server.nPort,
									m_BaseInfo.ConnAddr.Client.nIP,
									m_BaseInfo.ConnAddr.Client.nPort,
									&lradius_info);
			
			g_radiusStatInfo.u64QueryTimes++;

			if (0 == result)
			{
				g_radiusStatInfo.u64QuerySuccessTimes++;
				radius_query_to_process_data(lradius_info);
			}
			
			else if(1 == result)
			{
				g_radiusStatInfo.u64FindPool++;
			}
		}
		//--- end ---		
		

		if( (result == 0) && ( strncmp(m_BaseInfo.CdmaInfo.szMsID, lradius_info.calling_id, MSIDLEN) == 0) )
		{
			if(strncmp(lradius_info.called_id, "86", 2) == 0)
			{
				strncpy ( m_BaseInfo.CdmaInfo.szGreKey, lradius_info.called_id + 2, MAX_MSISDN_SIZE );
				m_BaseInfo.CdmaInfo.szGreKey[MAX_MSISDN_SIZE-5] = '\0';
				
//			strncpy ( m_BaseInfo.szAccount, lradius_info.user_name, USER_NAME_SIZE ) ;
			}
			else 
			{	
				if(strlen(lradius_info.called_id) == 11)
				{
					strncpy ( m_BaseInfo.CdmaInfo.szGreKey, lradius_info.called_id, MAX_MSISDN_SIZE );
					m_BaseInfo.CdmaInfo.szGreKey[MAX_MSISDN_SIZE-5] = '\0';
					strncpy ( m_BaseInfo.szAccount, lradius_info.user_name, USER_NAME_SIZE ) ;
				}
			}
		}
	}
#if 0
	else if( WIRELESS_MOBILE_NET == g_DataSource || WIRELESS_UNICOM_NET == g_DataSource)
	{
		pdp_t *pdp = NULL;
		pdp_t lpdp;
		memset(&lpdp, 0, sizeof(pdp_t));
		if(!gsn || !gsn->pdphdl)
			return;

#define DBG_NEW_SYNC
#ifdef DBG_NEW_SYNC
		static UINT32 u32FindMsg = 0;
		static UINT32 u32FoundMsg = 0;
		static UINT32 u32Found = 0;
		static UINT32 u32FoundCache = 0;
        static UINT32 u32GtpuNo = 0;
        static UINT32 u32OldTime = g_nCurTime;
		double dRate = 0;
        double dSuccRate = 0;
#endif

		if ((0 != ConnectAddresscdma.SubConnAddr.Server.nIP) && (0 != ConnectAddresscdma.SubConnAddr.Client.nIP))
		{
            u32GtpuNo++;
            u32GtpuNoStat++;
    		if(!(pdp = pdp_teidu_find_cpy(gsn->pdphdl, Grekeycdma, ConnectAddresscdma.SubConnAddr.Client.nIP, ConnectAddresscdma.SubConnAddr.Server.nIP, &lpdp)))
    		{
    			pdp = pdp_teidd_find_cpy(gsn->pdphdl, Grekeycdma, ConnectAddresscdma.SubConnAddr.Server.nIP, ConnectAddresscdma.SubConnAddr.Client.nIP, &lpdp);
    		}
			
            if (pdp == NULL && g_IsSigChannel == 0) 
            {
#ifdef DBG_NEW_SYNC
                u32FindMsg++;
#endif                
                    
                result = GtpRemoteQuery(Grekeycdma, ConnectAddresscdma.SubConnAddr.Client.nIP, ConnectAddresscdma.SubConnAddr.Server.nIP, &lpdp);
                if (0 == result)
                {
                    gtp_cache_add((char *)(&lpdp));
                    pdp = &lpdp;                
#ifdef DBG_NEW_SYNC
                    u32FoundMsg++;
#endif
                }
            }

            
#ifdef DBG_NEW_SYNC
            if (pdp)
            {
    			u32Found++;
            }
			
            if (g_nCurTime - u32OldTime >= g_nDbgInterval)
            {
                u32OldTime = g_nCurTime;
                
                if (u32FindMsg != 0)
                {
                    dRate = (double)u32FoundMsg / (double)u32FindMsg;
                }

                if (u32GtpuNo != 0)
                {
                    dSuccRate = (double)u32Found / (double)u32GtpuNo;
                }
                
    			u32FoundCache = u32Found - u32FoundMsg;

                DUMPSYSLOG("LWX","CAppBase","InitBase","relate times:%d, found in cache:%d, query msgs:%d, query success:%d, query success rate:%10.4lf, query lost:%d, success rate:%10.4lf",
                u32GtpuNo, u32FoundCache, u32FindMsg, u32FoundMsg, dRate, m_u32QueryLost, dSuccRate);
                u32GtpuNo = 0;
                u32Found = 0;
                u32FoundCache = 0;
                u32FindMsg = 0;
                u32FoundMsg= 0;
                m_u32QueryLost = 0;
            }
#endif
		}

		//stat,dongxia add
		if(pdp)
		{
			u32FoundStat++;		
		}
		
		if(g_nCurTime - u32OldTimeStamp >= 5)
		{
			u32OldTimeStamp = g_nCurTime;
			if (u32GtpuNoStat != 0)
			{
				g_nCurAssociaRate = (u32FoundStat * 100) / u32GtpuNoStat;	
				//g_nCurAssociaRate++;
			}
			else
			{
				g_nCurAssociaRate = 0;
			}
			u32FoundStat = 0;
			u32GtpuNoStat = 0;	
		}
		
		if(pdp)
		{
            if((g_nCurTime > lpdp.timestamp) && ((g_nCurTime - lpdp.timestamp) >(UINT32)(gsn->pdp_timeout/2)))
            {
                lpdp.msgtype = GTP_GPDU;
                lpdp.timestamp = g_nCurTime;
                gtp_trans_data(&lpdp, NULL);     	       
            }	
			m_BaseInfo.CdmaInfo.nDataSource	= g_DataSource;
			//m_BaseInfo.CdmaInfo.nHomeIp	= (&lpdp)->loc_type + 1; 
			//����֤�����ֶθ�ֵ xjh begain
			sprintf(m_BaseInfo.szAuthType, "%s", "1020004");
			//����֤�����ֶθ�ֵ xjh end

			if((&lpdp)->rat_type == 1)
				m_BaseInfo.CdmaInfo.nHomeIp	= 2;
			else if((&lpdp)->rat_type == 2)
				m_BaseInfo.CdmaInfo.nHomeIp	= 1;
			else
				m_BaseInfo.CdmaInfo.nHomeIp = (&lpdp)->rat_type;
			
			m_BaseInfo.CdmaInfo.nPcfIp	= (&lpdp)->sgsnc;
			m_BaseInfo.CdmaInfo.nPdsnIp	= (&lpdp)->ggsnc;
			
			if(!memcmp((&lpdp)->msisdn, "086", 3))
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, &(&lpdp)->msisdn[3], MAX_MSISDN_SIZE-3);
			else if(!memcmp((&lpdp)->msisdn, "86", 2))
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, &(&lpdp)->msisdn[2], MAX_MSISDN_SIZE-2);
			else
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, (&lpdp)->msisdn, MAX_MSISDN_SIZE);
			m_BaseInfo.CdmaInfo.szGreKey[MAX_MSISDN_SIZE-1] = '\0';
			
			imsi_int_to_str((&lpdp)->imsi, m_BaseInfo.CdmaInfo.szMsID);
			m_BaseInfo.CdmaInfo.szMsID[MAX_IMSI_SIZE-1] = '\0';
			
			strncpy(m_BaseInfo.CdmaInfo.szBsID, (&lpdp)->uli, MAX_ULI_SIZE);
			m_BaseInfo.CdmaInfo.szBsID[MAX_ULI_SIZE-1] = '\0';
			strncpy(m_BaseInfo.CdmaInfo.szEsnID, (&lpdp)->imei, MAX_IMEI_SIZE);
			m_BaseInfo.CdmaInfo.szEsnID[MAX_IMEI_SIZE-1] = '\0';
		}
		else
			return;
		
		CServiceBase::AppProtoToGtpFilter(m_MatchingResult, m_BaseInfo);
	}
#endif
	else if( WIRELESS_MOBILE_NET == g_DataSource 
		|| WIRELESS_UNICOM_NET == g_DataSource
		|| WIRELESS_LTE_NET == g_DataSource)
	{
	
		char gtp2_trans_context[GTP2_MAX_TRANS_LEN] = {0};
		int gtp2_trans_len = GTP2_MAX_TRANS_LEN;
		s11_pdn_t *pdn_found = NULL;
		s11_pdn_t *pdn = NULL;
		
		char s1ap_trans_context[S1AP_MAX_TRANS_LEN] = {0};
		int s1ap_trans_len = S1AP_MAX_TRANS_LEN;
		s1mme_pdn_t *s1mmepdn_found = NULL;
		s1mme_pdn_t *s1mmepdn = NULL;
		
		char lte_trans_context[GTP2_MAX_TRANS_LEN + S1AP_MAX_TRANS_LEN] = {0};
		int lte_trans_len = GTP2_MAX_TRANS_LEN + S1AP_MAX_TRANS_LEN;
		uint8_t query_result = 0;
		int offlen = 0;
		
		if(!lte || !lte->pdnhdl || !lte->s1mme_pdnhash)
			return;
		
		Fteid_t fd;
		memset(&fd, 0, sizeof(Fteid_t));
		fd.ip = ConnectAddresscdma.SubConnAddr.Server.nIP; 
		fd.teid = Grekeycdma;

		if (0 != fd.ip)
		{
			lte->gtp2_runstat.search_tol++;
			if(!(pdn_found = pdn_sgwu_fteid_find_cpy(lte->pdnhdl, fd, gtp2_trans_context, &gtp2_trans_len)))
			{
				pdn_found = pdn_eNB_fteid_find_cpy(lte->pdnhdl, fd, gtp2_trans_context, &gtp2_trans_len);
			}
			
			if( pdn_found != NULL)
			{
				lte->gtp2_runstat.search_suc_local++;
			}
			if(WIRELESS_LTE_NET == g_DataSource)
			{
				s1mme_fteid_t s1mme_fteid;
				s1mme_fteid.teid = Grekeycdma;
				s1mme_fteid.ip = ConnectAddresscdma.SubConnAddr.Server.nIP;

				lte->s1ap_runstat.search_tol++;
				if(!(s1mmepdn_found = s1mme_bearer_hash_find_cpy(lte->s1mme_pdnhash, &s1mme_fteid, SGW_TYPE, s1ap_trans_context, &s1ap_trans_len)))
				{
					s1mmepdn_found = s1mme_bearer_hash_find_cpy(lte->s1mme_pdnhash, &s1mme_fteid, ENB_TYPE, s1ap_trans_context, &s1ap_trans_len);
				}
				
				if( s1mmepdn_found != NULL)
				{
					lte->s1ap_runstat.search_suc_local++;
				}
			}
			if( (pdn_found == NULL && s1mmepdn_found == NULL)
				&& g_IsSigChannel == 0)
			{		
				result = LteRemoteQuery(&fd, lte_trans_context, lte_trans_len);

				if (0 == result)
				{	
					query_result = *((uint8_t *)lte_trans_context);
					offlen = 1;
					if((query_result & 0x01) == 1)
					{
						gtp2_trans_len = 1 + sizeof(s11_pdn_t) 
							+ *((uint8_t *)(lte_trans_context+offlen)) * sizeof(s11_bearer_t);
						if(gtp2_trans_len > GTP2_MAX_TRANS_LEN)
						{
							DUMPERRLOG("error", 0, "appbase", "initbase", "remote search", "gtp2_trans_len too long\n");
							return;
						}
						memcpy(gtp2_trans_context, lte_trans_context+offlen, gtp2_trans_len);
						offlen += gtp2_trans_len;
						
						pdn = (s11_pdn_t *)(gtp2_trans_context+1);
						pdn->msgtype = GTP2_SESSION_INLINE;
						gtp2_trans_data(gtp2_trans_context, gtp2_trans_len, 0);	
						pdn_found = pdn;
						lte->gtp2_runstat.search_suc_msg++;
					}
					if((query_result & 0x02) == 2)
					{
						s1ap_trans_len = 1 + sizeof(s1mme_pdn_t)
							+ *((uint8_t *)(lte_trans_context+offlen)) * sizeof(s1mme_bearer_t);
						if(s1ap_trans_len > S1AP_MAX_TRANS_LEN)
						{
							DUMPERRLOG("error", 0, "appbase", "initbase", "remote search", "s1ap_trans_len too long\n");
							return;
						}

						memcpy(s1ap_trans_context, lte_trans_context+offlen, s1ap_trans_len);
						offlen += s1ap_trans_len;
						
						s1mmepdn = (s1mme_pdn_t *)(s1ap_trans_context+1);
						s1mmepdn->msg_type = S1AP_SESSION_INLINE;
						s1ap_trans_data(s1ap_trans_context, s1ap_trans_len, 0);	
						s1mmepdn_found = s1mmepdn;
						lte->s1ap_runstat.search_suc_msg++;
					}
				}
			}
		}

		if(pdn_found)
		{
		
			pdn = (s11_pdn_t *)(gtp2_trans_context+1);
			if( (g_nCurTime - pdn->timestamp) >(UINT32)(lte->pdn_timeout/2))
			{

				pdn->msgtype = GTP2_GPDU;
				pdn->timestamp = g_nCurTime;
				*gtp2_trans_context = 0;
				gtp2_trans_data(gtp2_trans_context, sizeof(s11_pdn_t)+1, 1);
			}
			m_BaseInfo.CdmaInfo.nDataSource	= g_DataSource;

			m_BaseInfo.CdmaInfo.nHomeIp = pdn->rat_type;
			
			m_BaseInfo.CdmaInfo.nPcfIp	= pdn->mme_s11.ip;
			m_BaseInfo.CdmaInfo.nPdsnIp	= pdn->sgw_s11.ip;
						
			if(!memcmp(pdn->msisdn, "86", 2))
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, &pdn->msisdn[2], GTP2_MAX_MSISDN_SIZE-2);
			else if(!memcmp(pdn->msisdn, "086", 3))
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, &pdn->msisdn[3], GTP2_MAX_MSISDN_SIZE-3);
			else
				strncpy(m_BaseInfo.CdmaInfo.szGreKey, pdn->msisdn, GTP2_MAX_MSISDN_SIZE);
			m_BaseInfo.CdmaInfo.szGreKey[GTP2_MAX_MSISDN_SIZE-1] = '\0';
			
			imsi_int_to_str(pdn->imsi, m_BaseInfo.CdmaInfo.szMsID);
			m_BaseInfo.CdmaInfo.szMsID[GTP2_MAX_IMSI_SIZE-1] = '\0';

		    char uli_type[MAX_ULI_SIZE] = {0};
			if(pdn->rat_type == 6)
			{
				sprintf(uli_type, "%03u%02u%u" , pdn->uli.mcc, 
					pdn->uli.mnc, 
					pdn->uli.ecgi.eci);
				//snprintf(uli_type, 4, "%03u", pdn->uli.mcc);
				//snprintf(&uli_type[3], 4, "%03u", pdn->uli.mnc);
				//snprintf(&uli_type[6], 11, "%010u", pdn->uli.ecgi.eci);
			}
			else if(pdn->rat_type == 1)
			{
				snprintf(uli_type, 4, "%03u", pdn->uli.mcc);
				snprintf(&uli_type[3], 4, "%03u", pdn->uli.mnc);
				snprintf(&uli_type[6], 6, "%05u", pdn->uli.sai.lac);
				snprintf(&uli_type[11], 6, "%05u", pdn->uli.sai.sac);
			}
			else if(pdn->rat_type == 2)
			{
				snprintf(uli_type, 4, "%03u", pdn->uli.mcc);
				snprintf(&uli_type[3], 4, "%03u", pdn->uli.mnc);
				snprintf(&uli_type[6], 6, "%05u", pdn->uli.cgi.lac);
				snprintf(&uli_type[11], 6, "%05u", pdn->uli.cgi.ci);
			}
			strncpy(m_BaseInfo.CdmaInfo.szBsID, uli_type, MAX_ULI_SIZE);
			m_BaseInfo.CdmaInfo.szBsID[MAX_ULI_SIZE-1] = '\0';
			
			strncpy(m_BaseInfo.CdmaInfo.szEsnID, pdn->imei, GTP2_MAX_IMEI_SIZE);
			m_BaseInfo.CdmaInfo.szEsnID[GTP2_MAX_IMEI_SIZE-1] = '\0';

			
			strncpy(m_BaseInfo.LteInfo.apn, pdn->apn, GTP2_MAX_APN_SIZE);
			m_BaseInfo.LteInfo.apn[GTP2_MAX_APN_SIZE-1] = '\0';
			
			m_BaseInfo.LteInfo.ue_ip = pdn->userip;
		}

		if(s1mmepdn_found)
		{
			s1mmepdn = (s1mme_pdn_t *)(s1ap_trans_context+1);
			if( (g_nCurTime - s1mmepdn->timestamp) > (UINT32)(lte->pdn_timeout/2))
			{

				s1mmepdn->msg_type = S1AP_KEEPALIVE;
				s1mmepdn->timestamp = g_nCurTime;
				*s1ap_trans_context = 0;
				s1ap_trans_data(s1ap_trans_context, sizeof(s1mme_pdn_t)+1, 1);
			}

			//��ֵ������Ϣ
			m_BaseInfo.LteInfo.mcc = s1mmepdn->mcc;
			m_BaseInfo.LteInfo.mnc = s1mmepdn->mnc;
			m_BaseInfo.LteInfo.mme_group_id = s1mmepdn->mme_group_id;
			m_BaseInfo.LteInfo.mme_code_id = s1mmepdn->mme_code;
			m_BaseInfo.LteInfo.mme_ip = s1mmepdn->mme_ueid.s1ap_ip;
			m_BaseInfo.LteInfo.enodeb_ip = s1mmepdn->eNB_ueid.s1ap_ip;
			char uli_type[MAX_ULI_SIZE] = {0};
			sprintf(uli_type, "%03u-%02u-%u-%u" , s1mmepdn->mcc, 
				s1mmepdn->mnc, 
				(s1mmepdn->eci>>8), 
				(s1mmepdn->eci & 0xFF));		
			strncpy(m_BaseInfo.LteInfo.ecgi, uli_type, MAX_ULI_SIZE);
			m_BaseInfo.LteInfo.ecgi[MAX_ULI_SIZE-1] = '\0';
		}

		CServiceBase::AppProtoToGtpFilter(m_MatchingResult, m_BaseInfo);
	}
	else
	{
		if ( g_radius_table == NULL )
		{
			return ;
		}
	
		if(GetAppModuleID() == 7 || GetAppModuleID() == 195)
		{
			//nat  radius 2��Э��Ĳ���Ҫ��������ֱ������
			return ;
		}


		struct IPv4TransportAddr inner = {0,0};
		
        g_radiusStatInfo.u64RelateTimes++;
        if( g_nat_table->get_is_open() )
		{
            result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Client.nIP, m_BaseInfo.ConnAddr.Client.nPort, 
                                                     &inner.nIP, &inner.nPort);
            if (0 != result)
            {
                result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Server.nIP, m_BaseInfo.ConnAddr.Server.nPort, 
                                                         &inner.nIP, &inner.nPort);
                if (0 != result)
                {
                    port_interger = m_BaseInfo.ConnAddr.Client.nPort / 4096;
                    result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Client.nIP, port_interger, 
                                                             &inner.nIP, &inner.nPort, 4096);
                    if (0 != result)
                    {
                        port_interger = m_BaseInfo.ConnAddr.Server.nPort / 4096;
                        result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Server.nIP, port_interger, 
                                                                 &inner.nIP, &inner.nPort, 4096);
                        if (0 != result)
                        {
                            if (m_BaseInfo.ConnAddr.Client.nPort  >= 1024)
                            {
                                port_interger = (m_BaseInfo.ConnAddr.Client.nPort - 1024) / 4096;
                                result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Client.nIP, port_interger, 
                                                                         &inner.nIP, &inner.nPort, 4096);
                            }
                            if ((0 != result) && (m_BaseInfo.ConnAddr.Server.nPort  >= 1024))
                            {
                                port_interger = (m_BaseInfo.ConnAddr.Server.nPort - 1024) / 4096;
                                result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Server.nIP, port_interger, 
                                                                         &inner.nIP, &inner.nPort, 4096);
                            }
                        }
                    }
                }
            }
			//add by wuzheng,���ӶԲ���Ϊ992��natЭ��֧��
			if(0 != result)
			{
				if (m_BaseInfo.ConnAddr.Client.nPort  >= 1024)
                {
					port_interger = (m_BaseInfo.ConnAddr.Client.nPort - 1024) / 992;
                    result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Client.nIP, port_interger, 
						&inner.nIP, &inner.nPort, 992);
                }
                if ((0 != result) && (m_BaseInfo.ConnAddr.Server.nPort  >= 1024))
                {
                    port_interger = (m_BaseInfo.ConnAddr.Server.nPort - 1024) / 992;
                    result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Server.nIP, port_interger, 
                                                             &inner.nIP, &inner.nPort, 992);
                }
            }
			//add by wuzheng,���ӶԲ���Ϊ2048��natЭ��֧��
			if(0 != result)
			{
				if (m_BaseInfo.ConnAddr.Client.nPort  >= 1024)
                {
					port_interger = (m_BaseInfo.ConnAddr.Client.nPort - 1024) / 2048;
                    result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Client.nIP, port_interger, 
						&inner.nIP, &inner.nPort, 2048);
                }
                if ((0 != result) && (m_BaseInfo.ConnAddr.Server.nPort  >= 1024))
                {
                    port_interger = (m_BaseInfo.ConnAddr.Server.nPort - 1024) / 2048;
                    result = g_nat_table->get_inner_by_outer(m_BaseInfo.ConnAddr.Server.nIP, port_interger, 
                                                             &inner.nIP, &inner.nPort, 2048);
                }
            }

			if( inner.nIP != 0)
			{
				//NAT�����Ƿ���Ӱ��   
				result = g_radius_table->get_by_framed_ip ( inner.nIP, g_portInterger, &lradius_info, 0) ;
			}


		}
		else
		{
            for (i = 0; i < 5; i++)
            {
                if (0 == g_natInfoForQuery[i].u16Step)
                {
                    port_interger = g_portInterger;
                }
                else if(m_BaseInfo.ConnAddr.Client.nPort  >= g_natInfoForQuery[i].u16FirstPort)
				{
					port_interger = (m_BaseInfo.ConnAddr.Client.nPort - g_natInfoForQuery[i].u16FirstPort) / g_natInfoForQuery[i].u16Step;
    			}
				result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Client.nIP,  port_interger, &lradius_info, m_BaseInfo.ConnAddr.Client.nPort) ;

                if (0 == result)
                {
                    g_natInfoForQuery[i].u64SucessTime++;
                    if (u32QueryTimes < 4294967295)
                    {
                        u32QueryTimes++;
                    }
                    break;
                }
            }
            if (result != 0)
            {
                for (i = 0; i < 5; i++)
                {
                        if (0 == g_natInfoForQuery[i].u16Step)
                        {
                            port_interger = g_portInterger;
                        }
                        else if(m_BaseInfo.ConnAddr.Server.nPort  >= g_natInfoForQuery[i].u16FirstPort)
        				{
        					port_interger = (m_BaseInfo.ConnAddr.Server.nPort - g_natInfoForQuery[i].u16FirstPort) / g_natInfoForQuery[i].u16Step;
            			}
    					result = g_radius_table->get_by_framed_ip ( m_BaseInfo.ConnAddr.Server.nIP,  port_interger, &lradius_info, m_BaseInfo.ConnAddr.Server.nPort) ;

                        if (0 == result)
                        {
                            g_natInfoForQuery[i].u64SucessTime++;
                            if (u32QueryTimes < 4294967295)
                            {
                                u32QueryTimes++;
                            }
                            break;
                        }
                }
            }

            if ((0 == u32QueryTimes % 500000) && (u32QueryTimes != 4294967295))
            {
                for(j = 0;j < 5;j++)
                {
                    for(i = 0;i < (5 - 1 - j); i++)
                    {
                        if(g_natInfoForQuery[i].u64SucessTime < g_natInfoForQuery[i + 1].u64SucessTime)
                        {
                            memcpy(&struNatTemp, &g_natInfoForQuery[i], sizeof(struct natHashInfo));
                            memcpy(&g_natInfoForQuery[i], &g_natInfoForQuery[i + 1], sizeof(struct natHashInfo));
                            memcpy(&g_natInfoForQuery[i + 1], &struNatTemp, sizeof(struct natHashInfo));
                        }
                    }
                }
            }
            
            if (0 != result)
            {
                result = radiusQuery(m_BaseInfo.ConnAddr.Server.nIP,
                                                   m_BaseInfo.ConnAddr.Server.nPort,
                                                   m_BaseInfo.ConnAddr.Client.nIP,
                                                   m_BaseInfo.ConnAddr.Client.nPort,
                                                   &lradius_info);
                g_radiusStatInfo.u64QueryTimes++;
                if (0 == result)
                {
                    g_radiusStatInfo.u64QuerySuccessTimes++;
                    radius_query_to_process_data(lradius_info);
                }
                else if(1 == result)
                {
                    g_radiusStatInfo.u64FindPool++;
                }

            }						
		}
		if ( result == 0 )
		{
            g_radiusStatInfo.u64FindPool++;
            g_radiusStatInfo.u64RelateSuccussTimes++;
            if(0 != g_radiusStatInfo.u64FindPool)
            {
                g_radiusStatInfo.u32NetRelateRate = g_radiusStatInfo.u64RelateSuccussTimes * 100 / g_radiusStatInfo.u64FindPool;
            }
            if (0 != g_radiusStatInfo.u64RelateTimes)
            {
                g_radiusStatInfo.u32GrossRelateRate = g_radiusStatInfo.u64RelateSuccussTimes * 100 / g_radiusStatInfo.u64RelateTimes;
            }

            strncpy ( m_BaseInfo.szPhonenum, lradius_info.calling_id, CALLING_ID_SIZE ) ;
			strncpy ( m_BaseInfo.szAccount, lradius_info.user_name, USER_NAME_SIZE ) ;
			//����֤�����ֶθ�ֵ xjh begain
			sprintf(m_BaseInfo.szAuthType, "%s", "1020001");
			//����֤�����ֶθ�ֵ xjh end

			if (lradius_info.port_type == 19 ) 
			{
				strncpy ( m_BaseInfo.CdmaInfo.szBsID, lradius_info.called_id, CALLING_ID_SIZE) ;
				printf("appbase called_id :%s \n", lradius_info.called_id );
				m_BaseInfo.CdmaInfo.nPcfIp = lradius_info.nas_ip ;
				sprintf ( m_BaseInfo.CdmaInfo.szUserZone, "%d", lradius_info.port_type);
			}
			CServiceBase::AppRadiusFilter(m_MatchingResult, m_BaseInfo);
		}
	}
	*/
}
/*==========================================================
* ������	    : InitBase
* ����ֵ	    :  void 
* ����		    :  IPv6 �Ự��ַ��������ַ��Mac��ַ����������
*                        :                         
* ���� 	    :	Ӧ�ò�����ʼ��:1:�������ݽṹ2:
* ����            :  ������                                     
*=========================================================*/
void CAppBase::InitBase(IPv6ConnectAddr& ConnectAddress,  IPv6TunnelData&  TunnelAddress,
	const UCHAR* pMC, UINT32 nDataType)
{
	
	
	(void)ConnectAddress;
	(void)TunnelAddress;
	(void)pMC;
	(void)nDataType;
	
	/*
	//m_BaseInfo IPv6 �Ự��ַ
	m_BaseInfo.ConnAddrIPv6.nProtocol = ConnectAddress.nProtocol;
	m_BaseInfo.ConnAddrIPv6.nFlowLable = ConnectAddress.nFlowLable;
	m_BaseInfo.ConnAddrIPv6.Client.nPort = ConnectAddress.Client.nPort;
	memcpy(m_BaseInfo.ConnAddrIPv6.Client.aIPv6, ConnectAddress.Client.aIPv6, 16);
	m_BaseInfo.ConnAddrIPv6.Server.nPort = ConnectAddress.Server.nPort;
	memcpy(m_BaseInfo.ConnAddrIPv6.Server.aIPv6, ConnectAddress.Server.aIPv6, 16);
	//m_BaseInfo IPv6 ������ַ
	m_BaseInfo.TunnelAddrIPv6.nIPType = TunnelAddress.nIPType;
	m_BaseInfo.TunnelAddrIPv6.addr_ipv4.nSrcIP = TunnelAddress.addr_ipv4.nSrcIP;
	m_BaseInfo.TunnelAddrIPv6.addr_ipv4.nDstIP = TunnelAddress.addr_ipv4.nDstIP;
	memcpy(m_BaseInfo.TunnelAddrIPv6.addr_ipv6.aSrcIPv6, TunnelAddress.addr_ipv6.aSrcIPv6, 16);
	memcpy(m_BaseInfo.TunnelAddrIPv6.addr_ipv6.aDstIPv6, TunnelAddress.addr_ipv6.aDstIPv6, 16);
	//m_BaseInfo IPv6 ��������
	m_BaseInfo.nIPv6DataType = nDataType;
	//MAC ��ַ��д
	SetClientMac(pMC,ConnectAddress.Client);
	SetServerMac(pMC,ConnectAddress.Server);

	//�ײ���������
	m_MatchingResult.LinkResult.clear();
	if (R_SUCCESS_TRUST == CServiceBase::LinkFilter(ConnectAddress,m_MatchingResult,(UINT32)m_nObjectID)) 
	{
		NoProcess();
	}	
	
	return;
	
	*/
}

// added by kedong 20080620
// ������ӳ����Ѵ���Ӧ�ò�������Ѽ�¼���б���Ϣ
// ���½��еײ���������
void CAppBase::UpdateMatchingResult()
{
	/*
	IPv4ConnectAddr ConnectAddress;
	ConnectAddress.Client = m_BaseInfo.ConnAddr.Client;
	ConnectAddress.Server = m_BaseInfo.ConnAddr.Server;
	ConnectAddress.nProtocol = m_BaseInfo.ConnAddr.nProtocol;
	
	m_MatchingResult.AppResult.clear();
	m_MatchingResult.LinkResult.clear();
	m_MatchingResult.RelatedResult.clear();
	// add by lzr
	m_bIsHitSpecialObjectClue = false;
//	m_bIsSpecialObjectAppAlreadyFiltered = false;
	m_SpecialObjectMatchingResult.LinkResult.clear();
	m_SpecialObjectMatchingResult.AppResult.clear();
	m_SpecialObjectMatchingResult.RelatedResult.clear();
	if(m_pSpecialObjectMemlink != NULL)//�������������ˣ����ﻺ�������ǰ�����б�İ����������
	{
		delete m_pSpecialObjectMemlink;
		m_pSpecialObjectMemlink = NULL;
	}
	

#ifdef _LINZHEN	
	if (R_SUCCESS_TRUST == CServiceBase::LinkFilter(ConnectAddress,m_MatchingResult,(const char*)m_BaseInfo.byClientMac,(const char*)m_BaseInfo.byServerMac,m_nObjectID)) 
	{
		NoProcess();
	}
									
	CServiceBase::AppProtoToA11Filter(m_MatchingResult, m_BaseInfo);
#else
	//����ǰ��������Ͳ���������
	if (R_SUCCESS_TRUST == CServiceBase::LinkFilter(ConnectAddress,m_MatchingResult,m_nObjectID)) 
	{
		NoProcess();
	}	

	CServiceBase::AppProtoToA11Filter(m_MatchingResult, m_BaseInfo);
	CServiceBase::AppProtoToGtpFilter(m_MatchingResult, m_BaseInfo);
#endif
	GetSpecialObjectLinkRelatedHitClues(m_MatchingResult,m_SpecialObjectMatchingResult);//add by lzr
	*/
}

//add by lzr for special object
int CAppBase::m_nSpecialObjectCapFileMaxSize = 1024;

void CAppBase::GetSpecialObjectLinkRelatedHitClues(const MatchingResult& matchingResult,
	 MatchingResult& SpecialObjectMatchingResult)
{
	(void)matchingResult;
	(void)SpecialObjectMatchingResult;
	
	/*
	SpecialObjectMatchingResult.LinkResult.clear();
	SpecialObjectMatchingResult.RelatedResult.clear();

	int size = matchingResult.LinkResult.size();
	ClueAttribute* pAttr = NULL;
	for(int i=0; i<size; i++)
	{
		pAttr = matchingResult.LinkResult[i];
		if(pAttr != NULL)
		{
			if ((pAttr->ID.nDataType & CA_DATATYPE_SPECIAL_OBJECT) == CA_DATATYPE_SPECIAL_OBJECT)
			{
				SpecialObjectMatchingResult.LinkResult.push_back(pAttr);
				m_bIsHitSpecialObjectClue = true;
			}
		}
	}

	size = matchingResult.RelatedResult.size();
	for(int i=0; i<size; i++)
	{
		if((matchingResult.RelatedResult[i].ID.nDataType & CA_DATATYPE_SPECIAL_OBJECT) == CA_DATATYPE_SPECIAL_OBJECT)
		{
			SpecialObjectMatchingResult.RelatedResult.push_back(matchingResult.RelatedResult[i]);
			m_bIsHitSpecialObjectClue = true;
		}
	}
	*/
}

void CAppBase::GetSpecialObjectAppHitClues(const MatchingResult& matchingResult, MatchingResult& SpecialObjectMatchingResult)
{
	(void)matchingResult;
	(void)SpecialObjectMatchingResult;
	/*
	//SpecialObjectMatchingResult.AppResult.clear();//���ﲻ������ض������б꼯�ϣ�������ֱ����б�ļ��ϱ�δ�б�����(��ͨ����)��յ����
	int size = matchingResult.AppResult.size();
	ClueAttribute* pAttr = NULL;
	for(int i=0; i<size; i++)
	{
		pAttr = matchingResult.AppResult[i];
		if(pAttr != NULL)
		{
			if ((pAttr->ID.nDataType & CA_DATATYPE_SPECIAL_OBJECT) == CA_DATATYPE_SPECIAL_OBJECT)
			{
				bool alreadyFilterd = false;//���ض������б꼯�������ж��Ƿ�������Ѿ��й�����
				//std::vector<ClueAttribute*>	AppResult;		//Ӧ�ò��б�ID
				for (std::vector<ClueAttribute*>::const_iterator it=SpecialObjectMatchingResult.AppResult.begin(); it!=SpecialObjectMatchingResult.AppResult.end(); ++it)
				{
					if((*it)->ID.strClueID == pAttr->ID.strClueID)
					{
						alreadyFilterd = true;
						break;
					}
				}
				if (!alreadyFilterd)
				{
					m_bIsHitSpecialObjectClue = true;
					hasHitSpecialAppClue = true;//add by lzr 2009-09-11 for rpc
					specialObjectRelateTime = pAttr->nValidate;
					SpecialObjectMatchingResult.AppResult.push_back(pAttr);
				}
			}
		}
	}
*/
}

void CAppBase::SpecialObjectCapOutPut(const char *databuffer, UINT32 dataLen)
{
	
	(void)databuffer;
	(void)dataLen;
	/*
	if(m_pSpecialObjectMemlink == NULL)
	{
		m_pSpecialObjectMemlink = new memlink();
		assert(m_pSpecialObjectMemlink);
	}
	timemark curTime;
	curTime.tm_sec = g_nCurTime;
	curTime.tm_usec = 0;
	m_pSpecialObjectMemlink->Append( databuffer, dataLen, curTime);
	if(m_pSpecialObjectMemlink->GetDataLen() >= m_nSpecialObjectCapFileMaxSize)
	{
		DataPublic *pub = new DataPublic;	
		memcpy(pub, &m_BaseInfo, sizeof(DataPublic));
		//DataOutRaw *dataout = new DataOutRaw(OUTPUTRAW_TYPE_SPECIAL_OBJECT, m_nObjectID, g_pConfigManager->GetNameByID( m_nObjectID) , pub, m_pSpecialObjectMemlink, true, NULL);
		//�����ض����󲻷�Э�����洢��ֻ�ǰ����������洢���������еİ����Ķ���ͬһ��Э��id��Э������Ҳ���ض������֣��������ʱ��û�����Э�������
		DataOutRaw *dataout = new DataOutRaw(OUTPUTRAW_TYPE_SPECIAL_OBJECT, SPECIAL_OBJECT_FAKE_PROTOCOL_ID,SPECIAL_OBJECT_FAKE_PROTOCOL_NAME, pub, m_pSpecialObjectMemlink, true, NULL);
		std::vector<OutputMatchingResult> *pServiceResult = new std::vector<OutputMatchingResult>;
		if(pServiceResult == NULL)
		{
			DUMPERRLOG("error", 0, "outputraw", "CAppBase", "SpecialObjectCapOutPut", "new std::vector<MatchingResult> failed");
			delete pub;
			delete dataout;
			return;
		}
		UINT32 client_ip = dataout->pPublicInfo->ConnAddr.Client.nIP;
		//CServiceBase::DispenseClues(dataout->nProtoID, m_SpecialObjectMatchingResult, pServiceResult, client_ip, IP_TYPE_NORMAL, false);
		//������ʱ�������ȷ��Э��id�����������ض�����ͳһ�ļٵ�Э��id
		CServiceBase::DispenseClues(m_nObjectID, m_SpecialObjectMatchingResult, pServiceResult, client_ip, IP_TYPE_NORMAL, false);
		dataout->pFitID = pServiceResult;
		g_pOutputRaw->AddDataToQueue(dataout);
		m_pSpecialObjectMemlink = NULL;
	}*/
}

CStr CAppBase::GetUrl()
{
	return "";
}

//add by xudong 20091009
//Ӧ�ò�����������ת��Դ��Ŀ��IP��MAC��ַ
void CAppBase::ReverseIPAndMac()
{/*
	UCHAR tmpMac[6] = {0};
	
	UINT32 nIP = m_BaseInfo.ConnAddr.Server.nIP;
	UINT16 nPort = m_BaseInfo.ConnAddr.Server.nPort;
	
	m_BaseInfo.ConnAddr.Server.nIP = m_BaseInfo.ConnAddr.Client.nIP;
	m_BaseInfo.ConnAddr.Server.nPort = m_BaseInfo.ConnAddr.Client.nPort;
	m_BaseInfo.ConnAddr.Client.nIP = nIP;
	m_BaseInfo.ConnAddr.Client.nPort = nPort;
	
	memcpy( tmpMac, m_BaseInfo.byClientMac, 6 );
	memcpy( m_BaseInfo.byClientMac, m_BaseInfo.byServerMac, 6 );
	memcpy( m_BaseInfo.byServerMac, tmpMac, 6 );*/
}

/*2010-7-16 duxin jingliang �������� begin*/ 

void CAppBase::CleanMatchingResult()
{/*
	m_MatchingResult.AppResult.clear();
	m_MatchingResult.LinkResult.clear();
	m_MatchingResult.RelatedResult.clear();

	m_bIsHitSpecialObjectClue = false;

	m_SpecialObjectMatchingResult.LinkResult.clear();
	m_SpecialObjectMatchingResult.AppResult.clear();
	m_SpecialObjectMatchingResult.RelatedResult.clear();
	if(m_pSpecialObjectMemlink != NULL)//�������������ˣ����ﻺ�������ǰ�����б�İ����������
	{
		delete m_pSpecialObjectMemlink;
		m_pSpecialObjectMemlink = NULL;
	}*/
}

/*2010-7-16 duxin jingliang �������� end*/

///ȡ���ļ�����չ�������ָ���'.'
const char* CAppBase::GetExtName(const char* pName, int nLen)
{
	const char *p = ".dat";
	if (nLen>=3 && pName[nLen-2]=='.')
		return (pName + nLen - 2);
	if (nLen>=4 && pName[nLen-3]=='.')
		return (pName + nLen - 3);
	if (nLen>=5 && pName[nLen-4]=='.')
		return (pName + nLen - 4);
	if (nLen>=6 && pName[nLen-5]=='.')
		return (pName + nLen - 5);
	if (nLen>=7 && pName[nLen-6]=='.')
		return (pName + nLen - 6);
	
	return p;
}

//IPv6 ip��ַ��,��ͬ����true,��ͬ����false
bool CAppBase::IPv6AddrCompare(const UINT16 *pAddr1, const UINT16 *pAddr2)
{
	/*IPv6 ��ַ�ȽϹ���
	  1:128λ8 ��UINT16�����
	*/
	bool bRet = false;
	int i = 0;
	if ( NULL == pAddr1 || NULL == pAddr2 )
	{
		return bRet;
	}
	for( ; i < 8; i ++)
	{
		if ( *(pAddr1 + i) != *(pAddr2 + i) )
		{
			break;
		}
	}
	if (8 == i )
	{
		bRet = true;
	}
	return bRet;
}

int CAppBase::PreConnectCheck(UCHAR *pData , UINT32 nDataLen)
{
	(void)pData;
	(void)nDataLen;
	return 0;
}

