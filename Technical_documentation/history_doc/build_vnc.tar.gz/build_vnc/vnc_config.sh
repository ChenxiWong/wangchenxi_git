# Last Update:2016-09-06 16:01:12
#########################################################################
# File Name: vnc_config.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: 2016年09月06日 星期二 16时01分12秒
#########################################################################
#!/bin/bash 
rpm -ivh libvncserver-0.9.9-9.el7_0.1.x86_64.rpm
rpm -ivh tigervnc-server-1.3.1-3.el7.x86_64.rpm tigervnc-server-minimal-1.3.1-3.el7.x86_64.rpm tigervnc-license-1.3.1-3.el7.noarch.rpm
cp /lib/systemd/system/vncserver@.service /etc/systemd/system/vncserver@_1.service
"vim /etc/systemd/system/vncserver@_1.service 根据需要作出修改"
systemctl daemon-reload
systemctl enable vncserver@_1.service
systemctl start vncserver@_1.service
systemctl status vncserver@_1.service
vncpasswd
"vim  /etc/sysconfig/iptables 根据需要作出修改"
firewall-cmd --permanent --add-service vnc-server
systemctl restart firewalld.service
